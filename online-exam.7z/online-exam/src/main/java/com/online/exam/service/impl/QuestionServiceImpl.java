package com.online.exam.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.online.exam.dto.QuestionQueryDTO;
import com.online.exam.entity.Question;
import com.online.exam.mapper.QuestionMapper;
import com.online.exam.service.QuestionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Slf4j
@Service
public class QuestionServiceImpl extends ServiceImpl<QuestionMapper, Question> implements QuestionService {

    @Override
    public Page<Question> queryQuestions(QuestionQueryDTO dto) {
        Page<Question> page = new Page<>(dto.getPageNum(), dto.getPageSize());
        return baseMapper.selectQuestionPage(page, dto);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean addQuestion(Question question) {
        // 设置默认值
        if (question.getDifficulty() == null) {
            question.setDifficulty(3);
        }
        if (question.getScore() == null) {
            question.setScore(5);
        }
        if (question.getStatus() == null) {
            question.setStatus(1);
        }

        return save(question);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateQuestion(Question question) {
        if (question.getId() == null) {
            throw new RuntimeException("题目ID不能为空");
        }
        return updateById(question);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean deleteQuestion(Long id) {
        return removeById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean enableQuestion(Long id) {
        Question question = new Question();
        question.setId(id);
        question.setStatus(1);
        return updateById(question);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean disableQuestion(Long id) {
        Question question = new Question();
        question.setId(id);
        question.setStatus(0);
        return updateById(question);
    }
}