package com.online.exam.dto;

import lombok.Data;
import java.util.List;

@Data
public class ExamSubmitDTO {

    private Long examRecordId;

    private List<AnswerDTO> answers;

    @Data
    public static class AnswerDTO {
        private Long questionId;
        private String studentAnswer;
    }
}