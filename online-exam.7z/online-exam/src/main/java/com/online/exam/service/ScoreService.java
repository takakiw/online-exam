package com.online.exam.service;

import com.alibaba.fastjson2.JSONObject;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.online.exam.dto.ScoreQueryDTO;
import com.online.exam.dto.ScoreSubmitDTO;
import com.online.exam.entity.ExamScore;
import com.online.exam.entity.ExamRecord;

import java.util.List;

public interface ScoreService extends IService<ExamScore> {

    // 成绩管理
    ExamScore judgeExam(Long examRecordId);
    boolean manualJudge(ScoreSubmitDTO dto);
    Page<ExamScore> queryScores(ScoreQueryDTO dto);
    ExamScore getScoreDetail(Long examRecordId);
    List<ExamScore> getClassScores(Long classId, Long paperId);

    // 统计分析
    JSONObject getScoreStatistics(Long paperId, Long classId);
    JSONObject getStudentStatistics(Long studentId);

    // AI判卷
    ExamScore aiJudgeExam(Long examRecordId);
}