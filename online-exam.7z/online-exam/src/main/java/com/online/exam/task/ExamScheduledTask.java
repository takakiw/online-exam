package com.online.exam.task;

import com.online.exam.service.ExamService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class ExamScheduledTask {

    @Autowired
    private ExamService examService;

    /**
     * 每5分钟检查并自动提交过期考试
     */
    @Scheduled(cron = "${exam.auto-submit-cron:0 */5 * * * ?}")
    public void autoSubmitExpiredExams() {
        try {
            log.info("开始检查过期考试...");
            examService.autoSubmitExpiredExams();
            log.info("过期考试检查完成");
        } catch (Exception e) {
            log.error("自动提交过期考试失败", e);
        }
    }
}