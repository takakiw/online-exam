package com.online.exam.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.online.exam.dto.*;
import com.online.exam.entity.ClassEntity;
import com.online.exam.entity.ClassStudent;

public interface ClassService extends IService<ClassEntity> {

    // 班级管理
    ClassEntity createClass(ClassCreateDTO dto, Long teacherId, String teacherName);
    boolean updateClass(Long classId, ClassUpdateDTO dto);
    boolean deleteClass(Long classId);
    boolean endClass(Long classId);
    boolean reopenClass(Long classId);
    Page<ClassEntity> queryClasses(ClassQueryDTO dto);
    ClassEntity getClassDetail(Long classId);

    // 邀请码管理
    String generateInviteCode(Long classId, Integer expireDays);
    boolean disableInviteCode(Long classId);

    // 学生管理
    boolean joinClass(String inviteCode, Long studentId, String studentName, String studentUsername);
    boolean leaveClass(Long classId, Long studentId);
    boolean removeStudent(Long classId, Long studentId);
    Page<ClassStudent> queryClassStudents(ClassStudentQueryDTO dto);
    Page<ClassStudent> queryStudentClasses(Long studentId, Integer pageNum, Integer pageSize);

    // 验证
    boolean isClassTeacher(Long classId, Long teacherId);
    boolean isClassStudent(Long classId, Long studentId);
}