package com.online.exam.mapper;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.online.exam.dto.ScoreQueryDTO;
import com.online.exam.entity.ExamScore;

public interface ExamScoreMapper extends BaseMapper<ExamScore> {

    default Page<ExamScore> selectScorePage(Page<ExamScore> page, ScoreQueryDTO dto) {
        LambdaQueryWrapper<ExamScore> wrapper = new LambdaQueryWrapper<>();

        if (dto.getPaperId() != null) {
            wrapper.eq(ExamScore::getPaperId, dto.getPaperId());
        }
        if (dto.getStudentId() != null) {
            wrapper.eq(ExamScore::getStudentId, dto.getStudentId());
        }
        if (dto.getClassId() != null) {
            wrapper.eq(ExamScore::getClassId, dto.getClassId());
        }
        if (dto.getTeacherId() != null) {
            wrapper.eq(ExamScore::getTeacherId, dto.getTeacherId());
        }
        if (dto.getIsPassed() != null) {
            wrapper.eq(ExamScore::getIsPassed, dto.getIsPassed());
        }

        wrapper.orderByDesc(ExamScore::getSubmitTime);
        return selectPage(page, wrapper);
    }

    default ExamScore selectByExamRecordId(Long examRecordId) {
        LambdaQueryWrapper<ExamScore> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ExamScore::getExamRecordId, examRecordId);
        return selectOne(wrapper);
    }
}