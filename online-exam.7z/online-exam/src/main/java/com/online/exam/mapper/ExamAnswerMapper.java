package com.online.exam.mapper;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.online.exam.entity.ExamAnswer;
import java.util.List;

public interface ExamAnswerMapper extends BaseMapper<ExamAnswer> {

    default List<ExamAnswer> selectByExamRecordId(Long examRecordId) {
        LambdaQueryWrapper<ExamAnswer> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ExamAnswer::getExamRecordId, examRecordId);
        return selectList(wrapper);
    }

    default ExamAnswer selectByExamAndQuestion(Long examRecordId, Long questionId) {
        LambdaQueryWrapper<ExamAnswer> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ExamAnswer::getExamRecordId, examRecordId)
                .eq(ExamAnswer::getQuestionId, questionId);
        return selectOne(wrapper);
    }

    default boolean updateAnswerScore(Long id, Integer studentScore, Boolean isCorrect) {
        ExamAnswer answer = new ExamAnswer();
        answer.setId(id);
        answer.setStudentScore(studentScore);
        answer.setIsCorrect(isCorrect);
        return updateById(answer) > 0;
    }
}