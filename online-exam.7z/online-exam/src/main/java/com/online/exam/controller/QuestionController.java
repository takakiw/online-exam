package com.online.exam.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.online.exam.common.Result;
import com.online.exam.dto.QuestionQueryDTO;
import com.online.exam.entity.Question;
import com.online.exam.service.QuestionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@Slf4j
@Validated
@RestController
@RequestMapping("/api/question")
public class QuestionController {

    @Autowired
    private QuestionService questionService;

    /**
     * 分页查询题目
     */
    @PostMapping("/query")
    public Result<Page<Question>> queryQuestions(@Valid @RequestBody QuestionQueryDTO dto) {
        try {
            Page<Question> page = questionService.queryQuestions(dto);
            return Result.success(page, page.getTotal());
        } catch (Exception e) {
            log.error("查询题目失败", e);
            return Result.error("查询题目失败：" + e.getMessage());
        }
    }

    /**
     * 根据ID查询题目
     */
    @GetMapping("/{id}")
    public Result<Question> getQuestionById(@PathVariable Long id) {
        try {
            Question question = questionService.getById(id);
            if (question == null) {
                return Result.error(404, "题目不存在");
            }
            return Result.success(question);
        } catch (Exception e) {
            log.error("查询题目详情失败", e);
            return Result.error("查询题目详情失败：" + e.getMessage());
        }
    }

    /**
     * 添加题目
     */
    @PostMapping("/add")
    public Result<Boolean> addQuestion(@Valid @RequestBody Question question) {
        try {
            boolean success = questionService.addQuestion(question);
            if (success) {
                return Result.success(true);
            } else {
                return Result.error("添加题目失败");
            }
        } catch (Exception e) {
            log.error("添加题目失败", e);
            return Result.error("添加题目失败：" + e.getMessage());
        }
    }

    /**
     * 更新题目
     */
    @PutMapping("/update")
    public Result<Boolean> updateQuestion(@Valid @RequestBody Question question) {
        try {
            if (question.getId() == null) {
                return Result.error("题目ID不能为空");
            }
            boolean success = questionService.updateQuestion(question);
            if (success) {
                return Result.success(true);
            } else {
                return Result.error("更新题目失败");
            }
        } catch (Exception e) {
            log.error("更新题目失败", e);
            return Result.error("更新题目失败：" + e.getMessage());
        }
    }

    /**
     * 删除题目
     */
    @DeleteMapping("/delete/{id}")
    public Result<Boolean> deleteQuestion(@PathVariable Long id) {
        try {
            boolean success = questionService.deleteQuestion(id);
            if (success) {
                return Result.success(true);
            } else {
                return Result.error("删除题目失败");
            }
        } catch (Exception e) {
            log.error("删除题目失败", e);
            return Result.error("删除题目失败：" + e.getMessage());
        }
    }

    /**
     * 启用题目
     */
    @PutMapping("/enable/{id}")
    public Result<Boolean> enableQuestion(@PathVariable Long id) {
        try {
            boolean success = questionService.enableQuestion(id);
            if (success) {
                return Result.success(true);
            } else {
                return Result.error("启用题目失败");
            }
        } catch (Exception e) {
            log.error("启用题目失败", e);
            return Result.error("启用题目失败：" + e.getMessage());
        }
    }

    /**
     * 禁用题目
     */
    @PutMapping("/disable/{id}")
    public Result<Boolean> disableQuestion(@PathVariable Long id) {
        try {
            boolean success = questionService.disableQuestion(id);
            if (success) {
                return Result.success(true);
            } else {
                return Result.error("禁用题目失败");
            }
        } catch (Exception e) {
            log.error("禁用题目失败", e);
            return Result.error("禁用题目失败：" + e.getMessage());
        }
    }

    /**
     * 批量删除题目
     */
    @DeleteMapping("/batchDelete")
    public Result<Boolean> batchDeleteQuestions(@RequestParam("ids") Long[] ids) {
        try {
            for (Long id : ids) {
                questionService.deleteQuestion(id);
            }
            return Result.success(true);
        } catch (Exception e) {
            log.error("批量删除题目失败", e);
            return Result.error("批量删除题目失败：" + e.getMessage());
        }
    }
}