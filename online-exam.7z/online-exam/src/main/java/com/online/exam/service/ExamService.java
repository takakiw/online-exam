package com.online.exam.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.online.exam.dto.ExamQueryDTO;
import com.online.exam.dto.ExamSubmitDTO;
import com.online.exam.entity.ExamRecord;
import com.online.exam.entity.ExamAnswer;
import com.online.exam.entity.Paper;

import java.util.List;

public interface ExamService extends IService<ExamRecord> {

    // 考试管理
    ExamRecord startExam(Long paperId, Long studentId, String studentName, String username);
    boolean submitExam(ExamSubmitDTO dto);
    boolean autoSubmitExpiredExams();
    Page<ExamRecord> queryExamRecords(ExamQueryDTO dto);
    ExamRecord getExamRecord(Long examRecordId);

    // 考试答案管理
    boolean saveAnswer(Long examRecordId, Long questionId, String studentAnswer);
    List<ExamAnswer> getExamAnswers(Long examRecordId);
    ExamAnswer getExamAnswer(Long examRecordId, Long questionId);

    // 权限验证
    boolean isExamStudent(Long examRecordId, Long studentId);
    boolean isExamTeacher(Long paperId, Long teacherId);
}