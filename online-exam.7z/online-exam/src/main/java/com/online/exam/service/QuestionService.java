package com.online.exam.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.online.exam.dto.QuestionQueryDTO;
import com.online.exam.entity.Question;

public interface QuestionService extends IService<Question> {

    Page<Question> queryQuestions(QuestionQueryDTO dto);

    boolean addQuestion(Question question);

    boolean updateQuestion(Question question);

    boolean deleteQuestion(Long id);

    boolean enableQuestion(Long id);

    boolean disableQuestion(Long id);
}