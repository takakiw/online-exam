package com.online.exam.enums;

import lombok.Getter;

@Getter
public enum GenerateStrategyEnum {

    RANDOM("random", "随机生成"),
    GENETIC("genetic", "遗传算法"),
    WEIGHTED("weighted", "加权算法");

    private final String code;
    private final String name;

    GenerateStrategyEnum(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public static GenerateStrategyEnum getByCode(String code) {
        for (GenerateStrategyEnum strategy : values()) {
            if (strategy.getCode().equals(code)) {
                return strategy;
            }
        }
        return RANDOM;
    }
}