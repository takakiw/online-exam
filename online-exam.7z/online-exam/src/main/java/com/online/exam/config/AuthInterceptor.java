package com.online.exam.config;

import com.online.exam.common.AuthContext;
import com.online.exam.entity.User;
import com.online.exam.service.UserService;
import com.online.exam.util.JwtUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Slf4j
@Component
public class AuthInterceptor implements HandlerInterceptor {

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private UserService userService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // 获取token
        String token = extractToken(request);

        if (!StringUtils.hasText(token)) {
            // 允许公开访问的接口
            return true;
        }

        try {
            // 验证token
            if (!jwtUtil.validateToken(token)) {
                log.warn("Token验证失败: {}", token);
                return true;
            }

            // 从数据库验证用户
            User user = userService.getCurrentUser(token);
            if (user == null) {
                log.warn("用户不存在或token已过期: {}", token);
                return true;
            }

            // 设置认证上下文
            AuthContext authContext = new AuthContext();
            authContext.setUserId(user.getId());
            authContext.setUsername(user.getUsername());
            authContext.setRole(user.getRole());
            AuthContext.setContext(authContext);

            log.debug("用户认证成功: {}", user.getUsername());
        } catch (Exception e) {
            log.error("认证处理异常", e);
            // 认证失败不阻止请求，由具体接口处理
        }

        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        // 清理线程上下文
        AuthContext.clearContext();
    }

    private String extractToken(HttpServletRequest request) {
        String authHeader = request.getHeader("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            return authHeader.substring(7);
        }
        return null;
    }
}