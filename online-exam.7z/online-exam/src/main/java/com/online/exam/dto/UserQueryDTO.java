package com.online.exam.dto;

import lombok.Data;
import javax.validation.constraints.NotNull;

@Data
public class UserQueryDTO {

    private String keyword;

    private String role;

    private Integer status;

    @NotNull(message = "页码不能为空")
    private Integer pageNum = 1;

    @NotNull(message = "每页大小不能为空")
    private Integer pageSize = 10;
}