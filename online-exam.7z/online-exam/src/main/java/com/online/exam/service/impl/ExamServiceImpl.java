package com.online.exam.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.online.exam.common.AuthContext;
import com.online.exam.dto.ExamQueryDTO;
import com.online.exam.dto.ExamSubmitDTO;
import com.online.exam.entity.*;
import com.online.exam.enums.ExamStatusEnum;
import com.online.exam.enums.PaperStatusEnum;
import com.online.exam.mapper.ExamRecordMapper;
import com.online.exam.mapper.ExamAnswerMapper;
import com.online.exam.service.*;
import com.online.exam.util.ExamTimer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Service
public class ExamServiceImpl extends ServiceImpl<ExamRecordMapper, ExamRecord> implements ExamService {

    @Autowired
    private ExamAnswerMapper examAnswerMapper;

    @Autowired
    private PaperService paperService;

    @Autowired
    private PaperQuestionService paperQuestionService;

    @Autowired
    private ClassService classService;

    @Autowired
    @Lazy
    private ScoreService scoreService;

    @Autowired
    private ExamTimer examTimer;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ExamRecord startExam(Long paperId, Long studentId, String studentName, String username) {
        // 检查试卷是否存在且已发布
        Paper paper = paperService.getById(paperId);
        if (paper == null) {
            throw new RuntimeException("试卷不存在");
        }
        if (!PaperStatusEnum.PUBLISHED.getCode().equals(paper.getStatus())) {
            throw new RuntimeException("试卷未发布");
        }

        // 检查考试时间
        if (paper.getStartTime() != null && LocalDateTime.now().isBefore(paper.getStartTime())) {
            throw new RuntimeException("考试未开始");
        }
        if (paper.getEndTime() != null && LocalDateTime.now().isAfter(paper.getEndTime())) {
            throw new RuntimeException("考试已结束");
        }

        // 检查是否已有考试记录
        ExamRecord existingRecord = baseMapper.selectByPaperAndStudent(paperId, studentId);
        if (existingRecord != null) {
            // 如果考试已提交，不能重新开始
            if (ExamStatusEnum.SUBMITTED.getCode().equals(existingRecord.getStatus()) ||
                    ExamStatusEnum.JUDGED.getCode().equals(existingRecord.getStatus())) {
                throw new RuntimeException("已提交考试，不能重新开始");
            }
            // 如果考试已过期，可以重新开始
            if (ExamStatusEnum.EXPIRED.getCode().equals(existingRecord.getStatus())) {
                // 删除旧记录
                removeById(existingRecord.getId());
            } else {
                // 返回现有记录
                return existingRecord;
            }
        }

        // 检查学生是否在班级中
        if (paper.getClassId() != null) {
            if (!classService.isClassStudent(paper.getClassId(), studentId)) {
                throw new RuntimeException("您不在该班级中，无法参加考试");
            }
        }

        // 创建考试记录
        ExamRecord examRecord = new ExamRecord();
        examRecord.setPaperId(paperId);
        examRecord.setPaperName(paper.getPaperName());
        examRecord.setStudentId(studentId);
        examRecord.setStudentName(studentName);
        examRecord.setStudentUsername(username);
        examRecord.setClassId(paper.getClassId());
        examRecord.setClassName(paper.getClassName());
        examRecord.setTeacherId(paper.getTeacherId());
        examRecord.setTeacherName(paper.getTeacherName());
        examRecord.setStartTime(LocalDateTime.now());
        examRecord.setDuration(paper.getDuration());
        examRecord.setStatus(ExamStatusEnum.IN_PROGRESS.getCode());
        examRecord.setTotalScore(paper.getTotalScore()); // 从Paper获取总分
        examRecord.setAiJudgeEnabled(paper.getAiJudgeEnabled());

        save(examRecord);

        // 开始计时
        examTimer.startExam(examRecord.getId(), paper.getDuration());

        return examRecord;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean submitExam(ExamSubmitDTO dto) {
        ExamRecord examRecord = getById(dto.getExamRecordId());
        if (examRecord == null) {
            throw new RuntimeException("考试记录不存在");
        }

        // 检查权限
        if (!isExamStudent(dto.getExamRecordId(), AuthContext.getCurrentUserId())) {
            throw new RuntimeException("没有权限提交该考试");
        }

        // 检查考试状态
        if (!ExamStatusEnum.IN_PROGRESS.getCode().equals(examRecord.getStatus())) {
            throw new RuntimeException("考试状态不允许提交");
        }

        // 检查是否超时
        if (examTimer.isTimeout(dto.getExamRecordId(), examRecord.getDuration())) {
            examRecord.setStatus(ExamStatusEnum.EXPIRED.getCode());
            updateById(examRecord);
            throw new RuntimeException("考试已超时");
        }

        // 保存答案
        if (dto.getAnswers() != null) {
            for (ExamSubmitDTO.AnswerDTO answer : dto.getAnswers()) {
                saveAnswer(dto.getExamRecordId(), answer.getQuestionId(), answer.getStudentAnswer());
            }
        }

        // 更新考试状态
        examRecord.setStatus(ExamStatusEnum.SUBMITTED.getCode());
        examRecord.setSubmitTime(LocalDateTime.now());
        updateById(examRecord);

        // 结束计时
        examTimer.endExam(dto.getExamRecordId());

        // 自动判卷（如果客观题）
        scoreService.judgeExam(dto.getExamRecordId());

        return true;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean autoSubmitExpiredExams() {
        LambdaQueryWrapper<ExamRecord> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ExamRecord::getStatus, ExamStatusEnum.IN_PROGRESS.getCode())
                .lt(ExamRecord::getStartTime, LocalDateTime.now().minusMinutes(120));

        List<ExamRecord> records = list(wrapper);
        for (ExamRecord record : records) {
            try {
                record.setStatus(ExamStatusEnum.EXPIRED.getCode());
                updateById(record);
                log.info("自动提交过期考试：{}", record.getId());
            } catch (Exception e) {
                log.error("自动提交考试失败：{}", record.getId(), e);
            }
        }

        return true;
    }

    @Override
    public Page<ExamRecord> queryExamRecords(ExamQueryDTO dto) {
        Page<ExamRecord> page = new Page<>(dto.getPageNum(), dto.getPageSize());
        return baseMapper.selectExamPage(page, dto);
    }

    @Override
    public ExamRecord getExamRecord(Long examRecordId) {
        return getById(examRecordId);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean saveAnswer(Long examRecordId, Long questionId, String studentAnswer) {
        ExamRecord examRecord = getById(examRecordId);
        if (examRecord == null) {
            throw new RuntimeException("考试记录不存在");
        }

        // 检查考试状态
        if (!ExamStatusEnum.IN_PROGRESS.getCode().equals(examRecord.getStatus())) {
            throw new RuntimeException("考试已结束，不能保存答案");
        }

        // 获取试卷题目
        PaperQuestion paperQuestion = paperQuestionService.getPaperQuestions(examRecord.getPaperId())
                .stream()
                .filter(q -> q.getQuestionId().equals(questionId))
                .findFirst()
                .orElse(null);

        if (paperQuestion == null) {
            throw new RuntimeException("题目不在试卷中");
        }

        // 检查是否已有答案
        ExamAnswer existingAnswer = examAnswerMapper.selectByExamAndQuestion(examRecordId, questionId);

        if (existingAnswer != null) {
            // 更新答案
            existingAnswer.setStudentAnswer(studentAnswer);
            return examAnswerMapper.updateById(existingAnswer) > 0;
        } else {
            // 创建新答案
            ExamAnswer examAnswer = new ExamAnswer();
            examAnswer.setExamRecordId(examRecordId);
            examAnswer.setPaperId(examRecord.getPaperId());
            examAnswer.setQuestionId(questionId);
            examAnswer.setStudentId(examRecord.getStudentId());
            examAnswer.setStudentAnswer(studentAnswer);
            examAnswer.setCorrectAnswer(paperQuestion.getQuestionAnswer());
            examAnswer.setQuestionScore(paperQuestion.getQuestionScore());

            return examAnswerMapper.insert(examAnswer) > 0;
        }
    }

    @Override
    public List<ExamAnswer> getExamAnswers(Long examRecordId) {
        return examAnswerMapper.selectByExamRecordId(examRecordId);
    }

    @Override
    public ExamAnswer getExamAnswer(Long examRecordId, Long questionId) {
        return examAnswerMapper.selectByExamAndQuestion(examRecordId, questionId);
    }

    @Override
    public boolean isExamStudent(Long examRecordId, Long studentId) {
        if (examRecordId == null || studentId == null) {
            return false;
        }

        ExamRecord examRecord = getById(examRecordId);
        return examRecord != null && studentId.equals(examRecord.getStudentId());
    }

    @Override
    public boolean isExamTeacher(Long paperId, Long teacherId) {
        if (paperId == null || teacherId == null) {
            return false;
        }

        Paper paper = paperService.getById(paperId);
        return paper != null && teacherId.equals(paper.getTeacherId());
    }
}