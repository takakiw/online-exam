package com.online.exam.dto;

import lombok.Data;
import javax.validation.constraints.NotNull;

@Data
public class PaperQuestionDTO {

    @NotNull(message = "试卷ID不能为空")
    private Long paperId;

    @NotNull(message = "题目ID不能为空")
    private Long questionId;

    @NotNull(message = "题目分值不能为空")
    private Integer questionScore;

    private Integer sortOrder = 0;
}