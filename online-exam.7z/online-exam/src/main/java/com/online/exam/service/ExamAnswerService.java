package com.online.exam.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.online.exam.entity.ExamAnswer;

import java.util.List;

public interface ExamAnswerService extends IService<ExamAnswer> {

    List<ExamAnswer> getExamAnswers(Long examRecordId);

    ExamAnswer getExamAnswer(Long examRecordId, Long questionId);
}