package com.online.exam.dto;

import lombok.Data;

@Data
public class PaperRuleDTO {

    // 题目数量配置
    private Integer singleChoiceCount = 20;
    private Integer singleChoiceScore = 2;

    private Integer multipleChoiceCount = 10;
    private Integer multipleChoiceScore = 3;

    private Integer trueFalseCount = 10;
    private Integer trueFalseScore = 2;

    private Integer fillBlankCount = 5;
    private Integer fillBlankScore = 4;

    private Integer subjectiveCount = 2;
    private Integer subjectiveScore = 15;

    // 难度配置
    private Integer difficulty1Count = 5;  // 简单
    private Integer difficulty2Count = 10; // 较简单
    private Integer difficulty3Count = 15; // 中等
    private Integer difficulty4Count = 8;  // 较难
    private Integer difficulty5Count = 2;  // 困难

    // 章节配置
    private String[] chapters;

    // 知识点配置
    private String[] knowledgePoints;
}