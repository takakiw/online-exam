package com.online.exam.dto;

import lombok.Data;

@Data
public class ClassUpdateDTO {

    private String className;

    private String description;

    private Integer maxStudents;

    private Integer status;
}