package com.online.exam.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("exam_record")
public class ExamRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @TableField("paper_id")
    private Long paperId;

    @TableField("paper_name")
    private String paperName;

    @TableField("student_id")
    private Long studentId;

    @TableField("student_name")
    private String studentName;

    @TableField("student_username")
    private String studentUsername;

    @TableField("class_id")
    private Long classId;

    @TableField("class_name")
    private String className;

    @TableField("teacher_id")
    private Long teacherId;

    @TableField("teacher_name")
    private String teacherName;

    @TableField("start_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime startTime;

    @TableField("submit_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime submitTime;

    @TableField("duration")
    private Integer duration;

    @TableField("status")
    private Integer status;

    @TableField("total_score")
    private Integer totalScore;

    @TableField("score")
    private Integer score;

    @TableField("is_passed")
    private Boolean isPassed;

    @TableField("ai_judge_enabled")
    private Boolean aiJudgeEnabled;

    @TableField(value = "create_time", fill = FieldFill.INSERT)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    @TableField(value = "update_time", fill = FieldFill.INSERT_UPDATE)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;

    // 计算剩余时间（分钟）
    public Integer getRemainingTime() {
        if (submitTime != null) {
            return 0;
        }
        LocalDateTime endTime = startTime.plusMinutes(duration);
        LocalDateTime now = LocalDateTime.now();
        if (now.isAfter(endTime)) {
            return 0;
        }
        return (int) java.time.Duration.between(now, endTime).toMinutes();
    }
}