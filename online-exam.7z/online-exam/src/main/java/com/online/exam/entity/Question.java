package com.online.exam.entity;

import com.alibaba.fastjson2.JSONArray;
import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("question")
public class Question implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @TableField("content")
    private String content;

    @TableField("type")
    private String type;

    /**
     * 选项（JSON格式存储）
     */
    @TableField(value = "options", typeHandler = com.baomidou.mybatisplus.extension.handlers.FastjsonTypeHandler.class)
    private JSONArray options;

    @TableField("answer")
    private String answer;

    @TableField("analysis")
    private String analysis;

    @TableField("difficulty")
    private Integer difficulty;

    @TableField("subject")
    private String subject;

    @TableField("knowledge_point")
    private String knowledgePoint;

    @TableField("chapter")
    private String chapter;

    @TableField("score")
    private Integer score;

    @TableField("creator_id")
    private Long creatorId;

    @TableField("status")
    private Integer status;

    @TableField("ai_analysis_enabled")
    private Boolean aiAnalysisEnabled;

    @TableField("ai_judge_enabled")
    private Boolean aiJudgeEnabled;

    @TableField(value = "create_time", fill = FieldFill.INSERT)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    @TableField(value = "update_time", fill = FieldFill.INSERT_UPDATE)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;
}