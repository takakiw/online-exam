package com.online.exam.dto;

import lombok.Data;

@Data
public class ClassQueryDTO {

    private String keyword;

    private Long teacherId;

    private Integer status;

    private Integer pageNum = 1;

    private Integer pageSize = 10;
}