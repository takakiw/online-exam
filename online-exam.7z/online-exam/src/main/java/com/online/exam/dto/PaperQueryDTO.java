package com.online.exam.dto;

import lombok.Data;

@Data
public class PaperQueryDTO {

    private String keyword;

    private String paperType;

    private String subject;

    private Long teacherId;

    private Long classId;

    private Integer status;

    private Boolean aiJudgeEnabled;

    private Integer pageNum = 1;

    private Integer pageSize = 10;
}