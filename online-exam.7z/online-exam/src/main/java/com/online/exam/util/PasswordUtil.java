package com.online.exam.util;

import org.springframework.stereotype.Component;
import org.springframework.util.DigestUtils;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

@Component
public class PasswordUtil {

    /**
     * 生成盐值
     */
    public String generateSalt() {
        return UUID.randomUUID().toString().replaceAll("-", "").substring(0, 16);
    }

    /**
     * 加密密码
     */
    public String encryptPassword(String password, String salt) {
        String str = password + salt;
        return DigestUtils.md5DigestAsHex(str.getBytes(StandardCharsets.UTF_8));
    }

    /**
     * 验证密码
     */
    public boolean verifyPassword(String password, String salt, String encryptedPassword) {
        String encrypted = encryptPassword(password, salt);
        return encrypted.equals(encryptedPassword);
    }

    /**
     * 生成默认密码
     */
    public String generateDefaultPassword() {
        return "123456";
    }

    /**
     * 生成随机密码
     */
    public String generateRandomPassword() {
        return UUID.randomUUID().toString().replaceAll("-", "").substring(0, 8);
    }
}