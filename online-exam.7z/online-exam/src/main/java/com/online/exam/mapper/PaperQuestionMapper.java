package com.online.exam.mapper;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.online.exam.entity.PaperQuestion;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface PaperQuestionMapper extends BaseMapper<PaperQuestion> {

    default List<PaperQuestion> selectByPaperId(Long paperId) {
        LambdaQueryWrapper<PaperQuestion> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(PaperQuestion::getPaperId, paperId)
                .orderByAsc(PaperQuestion::getSortOrder);
        return selectList(wrapper);
    }

    default Page<PaperQuestion> selectByPaperIdPage(Page<PaperQuestion> page, Long paperId) {
        LambdaQueryWrapper<PaperQuestion> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(PaperQuestion::getPaperId, paperId)
                .orderByAsc(PaperQuestion::getSortOrder);
        return selectPage(page, wrapper);
    }

    default PaperQuestion selectByPaperAndQuestion(Long paperId, Long questionId) {
        LambdaQueryWrapper<PaperQuestion> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(PaperQuestion::getPaperId, paperId)
                .eq(PaperQuestion::getQuestionId, questionId);
        return selectOne(wrapper);
    }

    default boolean existsByPaperAndQuestion(Long paperId, Long questionId) {
        LambdaQueryWrapper<PaperQuestion> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(PaperQuestion::getPaperId, paperId)
                .eq(PaperQuestion::getQuestionId, questionId);
        return selectCount(wrapper) > 0;
    }

    default int deleteByPaperId(Long paperId) {
        LambdaQueryWrapper<PaperQuestion> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(PaperQuestion::getPaperId, paperId);
        return delete(wrapper);
    }
}