package com.online.exam.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.online.exam.dto.QuestionQueryDTO;
import com.online.exam.entity.Question;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public interface QuestionMapper extends BaseMapper<Question> {

    @Select("<script>" +
            "SELECT * FROM question WHERE 1=1 " +
            "<if test='dto.keyword != null and dto.keyword != \"\"'>" +
            "   AND content LIKE CONCAT('%', #{dto.keyword}, '%')" +
            "</if>" +
            "<if test='dto.type != null and dto.type != \"\"'>" +
            "   AND type = #{dto.type}" +
            "</if>" +
            "<if test='dto.subject != null and dto.subject != \"\"'>" +
            "   AND subject = #{dto.subject}" +
            "</if>" +
            "<if test='dto.chapter != null and dto.chapter != \"\"'>" +
            "   AND chapter = #{dto.chapter}" +
            "</if>" +
            "<if test='dto.difficulty != null'>" +
            "   AND difficulty = #{dto.difficulty}" +
            "</if>" +
            "<if test='dto.knowledgePoint != null and dto.knowledgePoint != \"\"'>" +
            "   AND knowledge_point LIKE CONCAT('%', #{dto.knowledgePoint}, '%')" +
            "</if>" +
            "<if test='dto.creatorId != null'>" +
            "   AND creator_id = #{dto.creatorId}" +
            "</if>" +
            "<if test='dto.status != null'>" +
            "   AND status = #{dto.status}" +
            "</if>" +
            " ORDER BY create_time DESC" +
            "</script>")
    Page<Question> selectQuestionPage(Page<Question> page, @Param("dto") QuestionQueryDTO dto);
}