package com.online.exam.dto;

import lombok.Data;
import javax.validation.constraints.NotNull;

@Data
public class QuestionQueryDTO {

    private String keyword;

    private String type;

    private String subject;

    private String chapter;

    private Integer difficulty;

    private String knowledgePoint;

    @NotNull(message = "页码不能为空")
    private Integer pageNum = 1;

    @NotNull(message = "每页大小不能为空")
    private Integer pageSize = 10;

    private Long creatorId;

    private Integer status;
}