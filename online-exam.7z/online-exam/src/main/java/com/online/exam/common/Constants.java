package com.online.exam.common;

public class Constants {

    // 用户角色
    public static final String ROLE_ADMIN = "admin";
    public static final String ROLE_TEACHER = "teacher";
    public static final String ROLE_STUDENT = "student";

    // 用户状态
    public static final Integer USER_STATUS_DISABLED = 0;
    public static final Integer USER_STATUS_ENABLED = 1;

    // 题目状态
    public static final Integer QUESTION_STATUS_DISABLED = 0;
    public static final Integer QUESTION_STATUS_ENABLED = 1;

    // 题目类型
    public static final String QUESTION_TYPE_SINGLE_CHOICE = "single_choice";
    public static final String QUESTION_TYPE_MULTIPLE_CHOICE = "multiple_choice";
    public static final String QUESTION_TYPE_TRUE_FALSE = "true_false";
    public static final String QUESTION_TYPE_FILL_BLANK = "fill_blank";
    public static final String QUESTION_TYPE_SUBJECTIVE = "subjective";

    // 难度级别
    public static final Integer DIFFICULTY_EASY = 1;
    public static final Integer DIFFICULTY_MEDIUM_EASY = 2;
    public static final Integer DIFFICULTY_MEDIUM = 3;
    public static final Integer DIFFICULTY_MEDIUM_HARD = 4;
    public static final Integer DIFFICULTY_HARD = 5;

    // Token前缀
    public static final String TOKEN_PREFIX = "Bearer ";

    // 响应状态码
    public static final Integer SUCCESS_CODE = 200;
    public static final Integer ERROR_CODE = 500;
    public static final Integer UNAUTHORIZED_CODE = 401;
    public static final Integer FORBIDDEN_CODE = 403;
    public static final Integer NOT_FOUND_CODE = 404;

    // 分页
    public static final Integer DEFAULT_PAGE_SIZE = 10;
    public static final Integer DEFAULT_PAGE_NUM = 1;

    // 默认密码
    public static final String DEFAULT_PASSWORD = "123456";
}