package com.online.exam.enums;

import lombok.Getter;

@Getter
public enum ScoreStatusEnum {

    NOT_PASSED(0, "不及格"),
    PASSED(1, "及格"),
    GOOD(2, "良好"),
    EXCELLENT(3, "优秀");

    private final Integer code;
    private final String name;

    ScoreStatusEnum(Integer code, String name) {
        this.code = code;
        this.name = name;
    }

    public static ScoreStatusEnum getByScore(Integer score, Integer totalScore) {
        double percentage = (double) score / totalScore * 100;
        if (percentage >= 90) return EXCELLENT;
        if (percentage >= 75) return GOOD;
        if (percentage >= 60) return PASSED;
        return NOT_PASSED;
    }
}