package com.online.exam.entity;

import lombok.Data;

import java.io.Serializable;

@Data
public class UserToken implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long userId;

    private String username;

    private String role;

    private String token;

    public UserToken() {}

    public UserToken(Long userId, String username, String role, String token) {
        this.userId = userId;
        this.username = username;
        this.role = role;
        this.token = token;
    }
}