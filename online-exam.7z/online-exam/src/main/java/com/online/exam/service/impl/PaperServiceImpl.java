package com.online.exam.service.impl;

import com.alibaba.fastjson2.JSONArray;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.online.exam.common.AuthContext;
import com.online.exam.dto.*;
import com.online.exam.entity.Paper;
import com.online.exam.entity.PaperQuestion;
import com.online.exam.entity.Question;
import com.online.exam.enums.PaperStatusEnum;
import com.online.exam.mapper.PaperMapper;
import com.online.exam.mapper.PaperQuestionMapper;
import com.online.exam.service.ClassService;
import com.online.exam.service.PaperService;
import com.online.exam.service.QuestionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Random;

@Slf4j
@Service
public class PaperServiceImpl extends ServiceImpl<PaperMapper, Paper> implements PaperService {

    @Autowired
    private PaperQuestionMapper paperQuestionMapper;

    @Autowired
    private QuestionService questionService;

    @Autowired
    private ClassService classService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Paper createPaper(PaperCreateDTO dto, Long teacherId, String teacherName) {
        // 创建试卷
        Paper paper = new Paper();
        BeanUtils.copyProperties(dto, paper);
        paper.setTeacherId(teacherId);
        paper.setTeacherName(teacherName);
        paper.setStatus(PaperStatusEnum.DRAFT.getCode());

        // 设置班级名称
        if (paper.getClassId() != null) {
            String className = classService.getClassDetail(paper.getClassId()).getClassName();
            paper.setClassName(className);
        }

        save(paper);

        // 如果指定了生成规则，自动生成试卷题目
        if (dto.getRule() != null) {
            generatePaper(paper.getId(), dto.getRule());
        }

        return paper;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updatePaper(Long paperId, PaperUpdateDTO dto) {
        Paper paper = getById(paperId);
        if (paper == null) {
            throw new RuntimeException("试卷不存在");
        }

        // 验证权限
        if (!isPaperTeacher(paperId, AuthContext.getCurrentUserId())) {
            throw new RuntimeException("没有权限修改试卷");
        }

        // 已发布的试卷不能修改基本信息
        if (PaperStatusEnum.PUBLISHED.getCode().equals(paper.getStatus())) {
            throw new RuntimeException("已发布的试卷不能修改");
        }

        if (StringUtils.hasText(dto.getPaperName())) {
            paper.setPaperName(dto.getPaperName());
        }
        if (StringUtils.hasText(dto.getDescription())) {
            paper.setDescription(dto.getDescription());
        }
        if (dto.getTotalScore() != null) {
            paper.setTotalScore(dto.getTotalScore());
        }
        if (dto.getPassScore() != null) {
            paper.setPassScore(dto.getPassScore());
        }
        if (dto.getDuration() != null) {
            paper.setDuration(dto.getDuration());
        }
        if (dto.getStatus() != null) {
            paper.setStatus(dto.getStatus());
        }
        if (dto.getStartTime() != null) {
            paper.setStartTime(dto.getStartTime());
        }
        if (dto.getEndTime() != null) {
            paper.setEndTime(dto.getEndTime());
        }
        if (dto.getAiJudgeEnabled() != null) {
            paper.setAiJudgeEnabled(dto.getAiJudgeEnabled());
        }

        return updateById(paper);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean deletePaper(Long paperId) {
        // 验证权限
        if (!isPaperTeacher(paperId, AuthContext.getCurrentUserId())) {
            throw new RuntimeException("没有权限删除试卷");
        }

        // 删除试卷题目
        paperQuestionMapper.deleteByPaperId(paperId);

        // 删除试卷
        return removeById(paperId);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean publishPaper(Long paperId) {
        Paper paper = new Paper();
        paper.setId(paperId);
        paper.setStatus(PaperStatusEnum.PUBLISHED.getCode());
        return updateById(paper);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean endPaper(Long paperId) {
        Paper paper = new Paper();
        paper.setId(paperId);
        paper.setStatus(PaperStatusEnum.ENDED.getCode());
        return updateById(paper);
    }

    @Override
    public Paper getPaperDetail(Long paperId) {
        return getById(paperId);
    }

    @Override
    public Page<Paper> queryPapers(PaperQueryDTO dto) {
        Page<Paper> page = new Page<>(dto.getPageNum(), dto.getPageSize());
        return baseMapper.selectPaperPage(page, dto);
    }

    @Override
    public Page<Paper> queryClassPapers(Long classId, Integer pageNum, Integer pageSize) {
        PaperQueryDTO dto = new PaperQueryDTO();
        dto.setClassId(classId);
        dto.setPageNum(pageNum);
        dto.setPageSize(pageSize);
        return queryPapers(dto);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean addQuestionToPaper(PaperQuestionDTO dto) {
        Paper paper = getById(dto.getPaperId());
        if (paper == null) {
            throw new RuntimeException("试卷不存在");
        }

        // 验证权限
        if (!isPaperTeacher(dto.getPaperId(), AuthContext.getCurrentUserId())) {
            throw new RuntimeException("没有权限修改试卷");
        }

        // 检查题目是否存在
        Question question = questionService.getById(dto.getQuestionId());
        if (question == null) {
            throw new RuntimeException("题目不存在");
        }

        // 检查是否已添加
        if (paperQuestionMapper.existsByPaperAndQuestion(dto.getPaperId(), dto.getQuestionId())) {
            throw new RuntimeException("题目已添加");
        }

        // 添加题目到试卷
        PaperQuestion paperQuestion = new PaperQuestion();
        paperQuestion.setPaperId(dto.getPaperId());
        paperQuestion.setQuestionId(dto.getQuestionId());
        paperQuestion.setQuestionContent(question.getContent());
        paperQuestion.setQuestionType(question.getType());
        paperQuestion.setQuestionOptions(question.getOptions());
        paperQuestion.setQuestionAnswer(question.getAnswer());
        paperQuestion.setQuestionAnalysis(question.getAnalysis());
        paperQuestion.setQuestionDifficulty(question.getDifficulty());
        paperQuestion.setQuestionScore(dto.getQuestionScore());
        paperQuestion.setSortOrder(dto.getSortOrder());

        return paperQuestionMapper.insert(paperQuestion) > 0;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean removeQuestionFromPaper(Long paperId, Long questionId) {
        // 验证权限
        if (!isPaperTeacher(paperId, AuthContext.getCurrentUserId())) {
            throw new RuntimeException("没有权限修改试卷");
        }

        LambdaQueryWrapper<PaperQuestion> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(PaperQuestion::getPaperId, paperId)
                .eq(PaperQuestion::getQuestionId, questionId);

        return paperQuestionMapper.delete(wrapper) > 0;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateQuestionScore(Long paperId, Long questionId, Integer score) {
        // 验证权限
        if (!isPaperTeacher(paperId, AuthContext.getCurrentUserId())) {
            throw new RuntimeException("没有权限修改试卷");
        }

        PaperQuestion paperQuestion = paperQuestionMapper.selectByPaperAndQuestion(paperId, questionId);
        if (paperQuestion == null) {
            throw new RuntimeException("试卷中不存在该题目");
        }

        paperQuestion.setQuestionScore(score);
        return paperQuestionMapper.updateById(paperQuestion) > 0;
    }

    @Override
    public List<PaperQuestion> getPaperQuestions(Long paperId) {
        return paperQuestionMapper.selectByPaperId(paperId);
    }

    @Override
    public Page<PaperQuestion> getPaperQuestionsPage(Long paperId, Integer pageNum, Integer pageSize) {
        Page<PaperQuestion> page = new Page<>(pageNum, pageSize);
        return paperQuestionMapper.selectByPaperIdPage(page, paperId);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean generatePaper(Long paperId, PaperRuleDTO rule) {
        Paper paper = getById(paperId);
        if (paper == null) {
            throw new RuntimeException("试卷不存在");
        }

        // 验证权限
        if (!isPaperTeacher(paperId, AuthContext.getCurrentUserId())) {
            throw new RuntimeException("没有权限生成试卷");
        }

        // 清空现有题目
        paperQuestionMapper.deleteByPaperId(paperId);

        // 根据规则生成试卷（简化实现）
        generateByRule(paper, rule);

        return true;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean autoGeneratePaper(Long paperId, String strategy) {
        Paper paper = getById(paperId);
        if (paper == null) {
            throw new RuntimeException("试卷不存在");
        }

        // 验证权限
        if (!isPaperTeacher(paperId, AuthContext.getCurrentUserId())) {
            throw new RuntimeException("没有权限生成试卷");
        }

        // 清空现有题目
        paperQuestionMapper.deleteByPaperId(paperId);

        // 根据策略生成试卷（简化实现）
        PaperRuleDTO rule = new PaperRuleDTO();
        generateByRule(paper, rule);

        return true;
    }

    @Override
    public boolean isPaperTeacher(Long paperId, Long teacherId) {
        if (paperId == null || teacherId == null) {
            return false;
        }

        Paper paper = getById(paperId);
        return paper != null && teacherId.equals(paper.getTeacherId());
    }

    // 根据规则生成试卷题目
    private void generateByRule(Paper paper, PaperRuleDTO rule) {
        // 这里简化实现，实际应该根据规则从题库中筛选题目

        // 示例：添加一些测试题目
        LambdaQueryWrapper<Question> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Question::getSubject, paper.getSubject())
                .eq(Question::getStatus, 1)
                .last("LIMIT 20");

        List<Question> questions = questionService.list(wrapper);

        Random random = new Random();
        int sortOrder = 0;
        int totalScore = 0;

        for (Question question : questions) {
            PaperQuestion paperQuestion = new PaperQuestion();
            paperQuestion.setPaperId(paper.getId());
            paperQuestion.setQuestionId(question.getId());
            paperQuestion.setQuestionContent(question.getContent());
            paperQuestion.setQuestionType(question.getType());
            paperQuestion.setQuestionOptions(question.getOptions());
            paperQuestion.setQuestionAnswer(question.getAnswer());
            paperQuestion.setQuestionAnalysis(question.getAnalysis());
            paperQuestion.setQuestionDifficulty(question.getDifficulty());
            paperQuestion.setQuestionScore(5); // 默认5分
            paperQuestion.setSortOrder(sortOrder++);

            paperQuestionMapper.insert(paperQuestion);
            totalScore += 5;
        }

        // 更新试卷总分
        if (totalScore != paper.getTotalScore()) {
            paper.setTotalScore(totalScore);
            updateById(paper);
        }
    }
}