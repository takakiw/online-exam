package com.online.exam.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.online.exam.entity.ExamAnswer;
import com.online.exam.mapper.ExamAnswerMapper;
import com.online.exam.service.ExamAnswerService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ExamAnswerServiceImpl extends ServiceImpl<ExamAnswerMapper, ExamAnswer> implements ExamAnswerService {

    @Override
    public List<ExamAnswer> getExamAnswers(Long examRecordId) {
        LambdaQueryWrapper<ExamAnswer> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ExamAnswer::getExamRecordId, examRecordId);
        return list(wrapper);
    }

    @Override
    public ExamAnswer getExamAnswer(Long examRecordId, Long questionId) {
        LambdaQueryWrapper<ExamAnswer> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ExamAnswer::getExamRecordId, examRecordId)
                .eq(ExamAnswer::getQuestionId, questionId);
        return getOne(wrapper);
    }
}