package com.online.exam.entity;

import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONObject;
import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;

@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("paper_question")
public class PaperQuestion implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @TableField("paper_id")
    private Long paperId;

    @TableField("question_id")
    private Long questionId;

    @TableField("question_content")
    private String questionContent;

    @TableField("question_type")
    private String questionType;

    @TableField(value = "question_options", typeHandler = com.baomidou.mybatisplus.extension.handlers.FastjsonTypeHandler.class)
    private JSONArray questionOptions;

    @TableField("question_answer")
    private String questionAnswer;

    @TableField("question_analysis")
    private String questionAnalysis;

    @TableField("question_difficulty")
    private Integer questionDifficulty;

    @TableField("question_score")
    private Integer questionScore;

    @TableField("sort_order")
    private Integer sortOrder;

    // 额外信息字段（不存储到数据库，仅用于返回）
    @TableField(exist = false)
    private JSONObject extraInfo;

}