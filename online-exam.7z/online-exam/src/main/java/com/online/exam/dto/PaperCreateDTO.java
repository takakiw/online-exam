package com.online.exam.dto;

import lombok.Data;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Data
public class PaperCreateDTO {

    @NotBlank(message = "试卷名称不能为空")
    private String paperName;

    @NotBlank(message = "试卷类型不能为空")
    private String paperType;

    private String description;

    private String subject;

    @NotNull(message = "总分不能为空")
    private Integer totalScore = 100;

    @NotNull(message = "及格分数不能为空")
    private Integer passScore = 60;

    @NotNull(message = "考试时长不能为空")
    private Integer duration = 120;

    private Long classId;

    private String generateStrategy = "random";

    private LocalDateTime startTime;

    private LocalDateTime endTime;

    private Boolean aiJudgeEnabled = false;

    // 题目生成规则
    private PaperRuleDTO rule;
}