package com.online.exam.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.online.exam.dto.*;
import com.online.exam.entity.Paper;
import com.online.exam.entity.PaperQuestion;

import java.util.List;

public interface PaperService extends IService<Paper> {

    // 试卷管理
    Paper createPaper(PaperCreateDTO dto, Long teacherId, String teacherName);
    boolean updatePaper(Long paperId, PaperUpdateDTO dto);
    boolean deletePaper(Long paperId);
    boolean publishPaper(Long paperId);
    boolean endPaper(Long paperId);
    Paper getPaperDetail(Long paperId);
    Page<Paper> queryPapers(PaperQueryDTO dto);
    Page<Paper> queryClassPapers(Long classId, Integer pageNum, Integer pageSize);

    // 试卷题目管理
    boolean addQuestionToPaper(PaperQuestionDTO dto);
    boolean removeQuestionFromPaper(Long paperId, Long questionId);
    boolean updateQuestionScore(Long paperId, Long questionId, Integer score);
    List<PaperQuestion> getPaperQuestions(Long paperId);

    Page<PaperQuestion> getPaperQuestionsPage(Long paperId, Integer pageNum, Integer pageSize);

    // 生成试卷
    boolean generatePaper(Long paperId, PaperRuleDTO rule);
    boolean autoGeneratePaper(Long paperId, String strategy);

    // 权限验证
    boolean isPaperTeacher(Long paperId, Long teacherId);
}