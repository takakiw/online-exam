package com.online.exam.enums;

import lombok.Getter;

@Getter
public enum PaperStatusEnum {

    DRAFT(0, "未发布"),
    PUBLISHED(1, "已发布"),
    ENDED(2, "已结束");

    private final Integer code;
    private final String name;

    PaperStatusEnum(Integer code, String name) {
        this.code = code;
        this.name = name;
    }

    public static PaperStatusEnum getByCode(Integer code) {
        for (PaperStatusEnum status : values()) {
            if (status.getCode().equals(code)) {
                return status;
            }
        }
        return DRAFT;
    }
}