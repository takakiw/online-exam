package com.online.exam.dto;

import lombok.Data;

@Data
public class ExamQueryDTO {

    private Long paperId;

    private Long studentId;

    private Long classId;

    private Long teacherId;

    private Integer status;

    private Boolean isPassed;

    private Integer pageNum = 1;

    private Integer pageSize = 10;
}