package com.online.exam.controller;

import com.alibaba.fastjson2.JSONObject;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.online.exam.common.AuthContext;
import com.online.exam.common.Result;
import com.online.exam.dto.ScoreQueryDTO;
import com.online.exam.dto.ScoreSubmitDTO;
import com.online.exam.entity.ExamScore;
import com.online.exam.service.ScoreService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Slf4j
@Validated
@RestController
@RequestMapping("/api/score")
public class ScoreController {

    @Autowired
    private ScoreService scoreService;

    // ==================== 成绩管理 ====================

    /**
     * 自动判卷
     */
    @PostMapping("/judge/{examRecordId}")
    public Result<ExamScore> judgeExam(@PathVariable Long examRecordId) {
        try {
            if (!AuthContext.isTeacher() && !AuthContext.isAdmin()) {
                return Result.error(403, "只有教师或管理员可以判卷");
            }

            ExamScore score = scoreService.judgeExam(examRecordId);
            return Result.success(score);
        } catch (Exception e) {
            log.error("自动判卷失败", e);
            return Result.error("自动判卷失败：" + e.getMessage());
        }
    }

    /**
     * 手动判卷（教师）
     */
    @PostMapping("/manual-judge")
    public Result<Boolean> manualJudge(@Valid @RequestBody ScoreSubmitDTO dto) {
        try {
            if (!AuthContext.isTeacher()) {
                return Result.error(403, "只有教师可以手动判卷");
            }

            boolean success = scoreService.manualJudge(dto);
            return success ? Result.success(true) : Result.error("手动判卷失败");
        } catch (Exception e) {
            log.error("手动判卷失败", e);
            return Result.error("手动判卷失败：" + e.getMessage());
        }
    }

    /**
     * AI判卷
     */
    @PostMapping("/ai-judge/{examRecordId}")
    public Result<ExamScore> aiJudgeExam(@PathVariable Long examRecordId) {
        try {
            if (!AuthContext.isTeacher() && !AuthContext.isAdmin()) {
                return Result.error(403, "只有教师或管理员可以使用AI判卷");
            }

            ExamScore score = scoreService.aiJudgeExam(examRecordId);
            return Result.success(score);
        } catch (Exception e) {
            log.error("AI判卷失败", e);
            return Result.error("AI判卷失败：" + e.getMessage());
        }
    }

    /**
     * 查询成绩列表
     */
    @PostMapping("/query")
    public Result<Page<ExamScore>> queryScores(@Valid @RequestBody ScoreQueryDTO dto) {
        try {
            // 权限检查
            if (AuthContext.isStudent()) {
                dto.setStudentId(AuthContext.getCurrentUserId());
            } else if (AuthContext.isTeacher()) {
                dto.setTeacherId(AuthContext.getCurrentUserId());
            }

            Page<ExamScore> page = scoreService.queryScores(dto);
            return Result.success(page, page.getTotal());
        } catch (Exception e) {
            log.error("查询成绩列表失败", e);
            return Result.error("查询成绩列表失败：" + e.getMessage());
        }
    }

    /**
     * 查询成绩详情
     */
    @GetMapping("/detail/{examRecordId}")
    public Result<ExamScore> getScoreDetail(@PathVariable Long examRecordId) {
        try {
            ExamScore score = scoreService.getScoreDetail(examRecordId);
            if (score == null) {
                return Result.error(404, "成绩记录不存在");
            }

            // 权限检查
            if (AuthContext.isStudent() &&
                    !score.getStudentId().equals(AuthContext.getCurrentUserId())) {
                return Result.error(403, "没有权限查看该成绩");
            }

            return Result.success(score);
        } catch (Exception e) {
            log.error("查询成绩详情失败", e);
            return Result.error("查询成绩详情失败：" + e.getMessage());
        }
    }

    /**
     * 查询班级成绩（教师）
     */
    @GetMapping("/class-scores/{classId}")
    public Result<List<ExamScore>> getClassScores(@PathVariable Long classId,
                                                  @RequestParam(required = false) Long paperId) {
        try {
            if (!AuthContext.isTeacher()) {
                return Result.error(403, "只有教师可以查看班级成绩");
            }

            List<ExamScore> scores = scoreService.getClassScores(classId, paperId);
            return Result.success(scores);
        } catch (Exception e) {
            log.error("查询班级成绩失败", e);
            return Result.error("查询班级成绩失败：" + e.getMessage());
        }
    }

    /**
     * 查询我的成绩（学生）
     */
    @GetMapping("/my-scores")
    public Result<Page<ExamScore>> getMyScores(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize) {
        try {
            if (!AuthContext.isStudent()) {
                return Result.error(403, "只有学生可以查看自己的成绩");
            }

            ScoreQueryDTO dto = new ScoreQueryDTO();
            dto.setStudentId(AuthContext.getCurrentUserId());
            dto.setPageNum(pageNum);
            dto.setPageSize(pageSize);

            Page<ExamScore> page = scoreService.queryScores(dto);
            return Result.success(page, page.getTotal());
        } catch (Exception e) {
            log.error("查询我的成绩失败", e);
            return Result.error("查询我的成绩失败：" + e.getMessage());
        }
    }

    /**
     * 查询试卷统计（教师）
     */
    @GetMapping("/paper-statistics/{paperId}")
    public Result<JSONObject> getPaperStatistics(@PathVariable Long paperId,
                                                 @RequestParam(required = false) Long classId) {
        try {
            if (!AuthContext.isTeacher()) {
                return Result.error(403, "只有教师可以查看试卷统计");
            }

            JSONObject statistics = scoreService.getScoreStatistics(paperId, classId);
            return Result.success(statistics);
        } catch (Exception e) {
            log.error("查询试卷统计失败", e);
            return Result.error("查询试卷统计失败：" + e.getMessage());
        }
    }

    /**
     * 查询学生统计（教师/学生）
     */
    @GetMapping("/student-statistics/{studentId}")
    public Result<JSONObject> getStudentStatistics(@PathVariable Long studentId) {
        try {
            // 权限检查：学生只能查看自己的统计
            if (AuthContext.isStudent() && !studentId.equals(AuthContext.getCurrentUserId())) {
                return Result.error(403, "没有权限查看其他学生的统计");
            }

            JSONObject statistics = scoreService.getStudentStatistics(studentId);
            return Result.success(statistics);
        } catch (Exception e) {
            log.error("查询学生统计失败", e);
            return Result.error("查询学生统计失败：" + e.getMessage());
        }
    }

    /**
     * 导出成绩（教师）
     */
    @GetMapping("/export/{paperId}")
    public Result<String> exportScores(@PathVariable Long paperId,
                                       @RequestParam(required = false) Long classId) {
        try {
            if (!AuthContext.isTeacher()) {
                return Result.error(403, "只有教师可以导出成绩");
            }

            // TODO: 实现导出功能
            return Result.success("导出功能待实现");
        } catch (Exception e) {
            log.error("导出成绩失败", e);
            return Result.error("导出成绩失败：" + e.getMessage());
        }
    }
}