package com.online.exam.dto;

import lombok.Data;
import javax.validation.constraints.NotBlank;

@Data
public class ClassCreateDTO {

    @NotBlank(message = "班级名称不能为空")
    private String className;

    private String description;

    private Integer maxStudents = 50;
}