package com.online.exam.util;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Component
public class ExamTimer {

    // 存储考试开始时间
    private final Map<Long, LocalDateTime> examStartTimes = new ConcurrentHashMap<>();

    /**
     * 开始考试计时
     */
    public void startExam(Long examRecordId, Integer durationMinutes) {
        examStartTimes.put(examRecordId, LocalDateTime.now());
        log.info("开始考试计时，记录ID：{}，时长：{}分钟", examRecordId, durationMinutes);
    }

    /**
     * 获取剩余时间（分钟）
     */
    public Integer getRemainingTime(Long examRecordId, Integer durationMinutes) {
        LocalDateTime startTime = examStartTimes.get(examRecordId);
        if (startTime == null) {
            return durationMinutes;
        }

        LocalDateTime endTime = startTime.plusMinutes(durationMinutes);
        LocalDateTime now = LocalDateTime.now();

        if (now.isAfter(endTime)) {
            return 0;
        }

        return (int) java.time.Duration.between(now, endTime).toMinutes();
    }

    /**
     * 检查是否超时
     */
    public boolean isTimeout(Long examRecordId, Integer durationMinutes) {
        Integer remaining = getRemainingTime(examRecordId, durationMinutes);
        return remaining <= 0;
    }

    /**
     * 结束考试计时
     */
    public void endExam(Long examRecordId) {
        examStartTimes.remove(examRecordId);
        log.info("结束考试计时，记录ID：{}", examRecordId);
    }
}