package com.online.exam.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.online.exam.common.AuthContext;
import com.online.exam.common.Result;
import com.online.exam.dto.ExamQueryDTO;
import com.online.exam.dto.ExamStartDTO;
import com.online.exam.dto.ExamSubmitDTO;
import com.online.exam.entity.ExamRecord;
import com.online.exam.entity.ExamAnswer;
import com.online.exam.service.ExamService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Slf4j
@Validated
@RestController
@RequestMapping("/api/exam")
public class ExamController {

    @Autowired
    private ExamService examService;

    // ==================== 考试管理 ====================

    /**
     * 开始考试（学生）
     */
    @PostMapping("/start")
    public Result<ExamRecord> startExam(@Valid @RequestBody ExamStartDTO dto) {
        try {
            if (!AuthContext.isStudent()) {
                return Result.error(403, "只有学生可以开始考试");
            }

            Long studentId = AuthContext.getCurrentUserId();
            String username = AuthContext.getCurrentUsername();

            // 获取学生姓名
            String studentName = AuthContext.getCurrentUsername(); // 简化处理

            ExamRecord record = examService.startExam(dto.getPaperId(), studentId, studentName, username);
            return Result.success(record);
        } catch (Exception e) {
            log.error("开始考试失败", e);
            return Result.error("开始考试失败：" + e.getMessage());
        }
    }

    /**
     * 提交考试（学生）
     */
    @PostMapping("/submit")
    public Result<Boolean> submitExam(@Valid @RequestBody ExamSubmitDTO dto) {
        try {
            if (!AuthContext.isStudent()) {
                return Result.error(403, "只有学生可以提交考试");
            }

            boolean success = examService.submitExam(dto);
            return success ? Result.success(true) : Result.error("提交考试失败");
        } catch (Exception e) {
            log.error("提交考试失败", e);
            return Result.error("提交考试失败：" + e.getMessage());
        }
    }

    /**
     * 保存答案（学生）
     */
    @PostMapping("/save-answer")
    public Result<Boolean> saveAnswer(@RequestParam Long examRecordId,
                                      @RequestParam Long questionId,
                                      @RequestParam String studentAnswer) {
        try {
            if (!AuthContext.isStudent()) {
                return Result.error(403, "只有学生可以保存答案");
            }

            boolean success = examService.saveAnswer(examRecordId, questionId, studentAnswer);
            return success ? Result.success(true) : Result.error("保存答案失败");
        } catch (Exception e) {
            log.error("保存答案失败", e);
            return Result.error("保存答案失败：" + e.getMessage());
        }
    }

    /**
     * 查询考试记录
     */
    @PostMapping("/records")
    public Result<Page<ExamRecord>> queryExamRecords(@Valid @RequestBody ExamQueryDTO dto) {
        try {
            // 权限检查
            if (AuthContext.isStudent()) {
                dto.setStudentId(AuthContext.getCurrentUserId());
            } else if (AuthContext.isTeacher()) {
                dto.setTeacherId(AuthContext.getCurrentUserId());
            }

            Page<ExamRecord> page = examService.queryExamRecords(dto);
            return Result.success(page, page.getTotal());
        } catch (Exception e) {
            log.error("查询考试记录失败", e);
            return Result.error("查询考试记录失败：" + e.getMessage());
        }
    }

    /**
     * 查询考试详情
     */
    @GetMapping("/detail/{examRecordId}")
    public Result<ExamRecord> getExamDetail(@PathVariable Long examRecordId) {
        try {
            ExamRecord record = examService.getExamRecord(examRecordId);
            if (record == null) {
                return Result.error(404, "考试记录不存在");
            }

            // 权限检查
            if (AuthContext.isStudent() &&
                    !record.getStudentId().equals(AuthContext.getCurrentUserId())) {
                return Result.error(403, "没有权限查看该考试记录");
            }

            return Result.success(record);
        } catch (Exception e) {
            log.error("查询考试详情失败", e);
            return Result.error("查询考试详情失败：" + e.getMessage());
        }
    }

    /**
     * 查询考试答案
     */
    @GetMapping("/answers/{examRecordId}")
    public Result<List<ExamAnswer>> getExamAnswers(@PathVariable Long examRecordId) {
        try {
            ExamRecord record = examService.getExamRecord(examRecordId);
            if (record == null) {
                return Result.error(404, "考试记录不存在");
            }

            // 权限检查
            if (AuthContext.isStudent() &&
                    !record.getStudentId().equals(AuthContext.getCurrentUserId())) {
                return Result.error(403, "没有权限查看考试答案");
            }

            List<ExamAnswer> answers = examService.getExamAnswers(examRecordId);
            return Result.success(answers);
        } catch (Exception e) {
            log.error("查询考试答案失败", e);
            return Result.error("查询考试答案失败：" + e.getMessage());
        }
    }

    /**
     * 获取剩余考试时间
     */
    @GetMapping("/remaining-time/{examRecordId}")
    public Result<Integer> getRemainingTime(@PathVariable Long examRecordId) {
        try {
            ExamRecord record = examService.getExamRecord(examRecordId);
            if (record == null) {
                return Result.error(404, "考试记录不存在");
            }

            // 权限检查
            if (AuthContext.isStudent() &&
                    !record.getStudentId().equals(AuthContext.getCurrentUserId())) {
                return Result.error(403, "没有权限查看考试时间");
            }

            Integer remainingTime = record.getRemainingTime();
            return Result.success(remainingTime);
        } catch (Exception e) {
            log.error("获取剩余考试时间失败", e);
            return Result.error("获取剩余考试时间失败：" + e.getMessage());
        }
    }

    /**
     * 自动提交过期考试（系统定时任务）
     */
    @PostMapping("/auto-submit-expired")
    public Result<Boolean> autoSubmitExpiredExams() {
        try {
            if (!AuthContext.isAdmin()) {
                return Result.error(403, "只有管理员可以执行此操作");
            }

            boolean success = examService.autoSubmitExpiredExams();
            return success ? Result.success(true) : Result.error("自动提交过期考试失败");
        } catch (Exception e) {
            log.error("自动提交过期考试失败", e);
            return Result.error("自动提交过期考试失败：" + e.getMessage());
        }
    }
}