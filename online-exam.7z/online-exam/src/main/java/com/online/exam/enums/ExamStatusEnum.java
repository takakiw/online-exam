package com.online.exam.enums;

import lombok.Getter;

@Getter
public enum ExamStatusEnum {

    IN_PROGRESS(0, "进行中"),
    SUBMITTED(1, "已提交"),
    JUDGED(2, "已判卷"),
    EXPIRED(3, "已过期");

    private final Integer code;
    private final String name;

    ExamStatusEnum(Integer code, String name) {
        this.code = code;
        this.name = name;
    }

    public static ExamStatusEnum getByCode(Integer code) {
        for (ExamStatusEnum status : values()) {
            if (status.getCode().equals(code)) {
                return status;
            }
        }
        return IN_PROGRESS;
    }
}