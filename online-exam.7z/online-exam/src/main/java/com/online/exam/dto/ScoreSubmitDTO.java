package com.online.exam.dto;

import lombok.Data;
import java.util.List;

@Data
public class ScoreSubmitDTO {

    private Long examRecordId;

    private List<QuestionScoreDTO> questionScores;

    @Data
    public static class QuestionScoreDTO {
        private Long questionId;
        private Integer studentScore;
    }
}