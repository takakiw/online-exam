package com.online.exam.entity;

import com.alibaba.fastjson2.JSONObject;
import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("exam_score")
public class ExamScore implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @TableField("exam_record_id")
    private Long examRecordId;

    @TableField("paper_id")
    private Long paperId;

    @TableField("paper_name")
    private String paperName;

    @TableField("student_id")
    private Long studentId;

    @TableField("student_name")
    private String studentName;

    @TableField("class_id")
    private Long classId;

    @TableField("class_name")
    private String className;

    @TableField("teacher_id")
    private Long teacherId;

    @TableField("total_score")
    private Integer totalScore;

    @TableField("score")
    private Integer score;

    @TableField("pass_score")
    private Integer passScore;

    @TableField("is_passed")
    private Boolean isPassed;

    @TableField(value = "score_detail", typeHandler = com.baomidou.mybatisplus.extension.handlers.FastjsonTypeHandler.class)
    private JSONObject scoreDetail;

    @TableField("submit_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime submitTime;

    @TableField("judge_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime judgeTime;

    @TableField(value = "create_time", fill = FieldFill.INSERT)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    // 计算得分率
    public Double getScoreRate() {
        if (totalScore == 0) return 0.0;
        return (double) score / totalScore * 100;
    }

    // 获取成绩等级
    public String getScoreLevel() {
        double rate = getScoreRate();
        if (rate >= 90) return "优秀";
        if (rate >= 75) return "良好";
        if (rate >= 60) return "及格";
        return "不及格";
    }
}