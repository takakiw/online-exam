package com.online.exam.util;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class DeepSeekUtil {

    @Value("${deepseek.api-key:sk-fa08dfe666904e4abf34bf8e17d74731}")
    private String apiKey;

    @Value("${deepseek.api-url:https://api.deepseek.com/v1/chat/completions}")
    private String apiUrl;

    private final RestTemplate restTemplate = new RestTemplate();

    /**
     * AI解析题目答案解析
     */
    public String analyzeQuestion(String questionContent, String answer) {
        try {
            log.info("调用DeepSeek API KEY{}", apiKey);
            String prompt = String.format("请解析以下题目：\n题目：%s\n答案：%s\n请给出详细的解析过程和知识点说明。",
                    questionContent, answer);

            // 构建请求体
            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("model", "deepseek-chat");
            requestBody.put("max_tokens", 2000);
            requestBody.put("stream", false);

            // 构建消息列表
            List<Map<String, String>> messages = new ArrayList<>();
            messages.add(createMessage("user", prompt));
            requestBody.put("messages", messages);

            // 设置请求头
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setBearerAuth(apiKey);

            // 创建 HTTP 实体
            HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(requestBody, headers);

            log.info("调用DeepSeek API分析题目：{}", questionContent);

            // 发送请求
            return  restTemplate.exchange(
                    apiUrl,
                    HttpMethod.POST,
                    requestEntity,
                    String.class
            ).getBody();


        } catch (Exception e) {
            log.error("AI解析题目失败", e);
            return "解析失败：" + e.getMessage();
        }
    }

    /**
     * 创建消息对象
     */
    private Map<String, String> createMessage(String role, String content) {
        Map<String, String> message = new HashMap<>();
        message.put("role", role);
        message.put("content", content);
        return message;
    }

    /**
     * AI判卷（主观题）
     */
    public JSONObject judgeSubjectiveQuestion(String questionContent, String correctAnswer,
                                              String studentAnswer, Integer maxScore) {
        try {
            String prompt = String.format("请对以下主观题进行判卷：\n题目：%s\n参考答案：%s\n学生答案：%s\n满分：%d分\n请给出评分和评语。",
                    questionContent, correctAnswer, studentAnswer, maxScore);

            Map<String, Object> request = new HashMap<>();
            request.put("model", "deepseek-chat");
            // Map.of("role", "user", "content", prompt)
            HashMap<String, Object> message = new HashMap<>();
            message.put("role", "user");
            message.put("content", prompt);
            request.put("messages", new Object[]{
                     message
            });
            request.put("max_tokens", 300);

            // 模拟返回结果
            JSONObject result = new JSONObject();
            result.put("score", calculateMockScore(studentAnswer, maxScore));
            result.put("comment", "AI评语：答案基本正确，表述清晰，可以得" + result.get("score") + "分。");
            result.put("suggestions", "建议加强相关知识点的理解。");

            return result;

        } catch (Exception e) {
            log.error("AI判卷失败", e);
            JSONObject result = new JSONObject();
            result.put("score", maxScore / 2);
            result.put("comment", "判卷失败，已给出基础分");
            return result;
        }
    }

    private int calculateMockScore(String studentAnswer, int maxScore) {
        if (studentAnswer == null || studentAnswer.trim().isEmpty()) {
            return 0;
        }
        // 模拟评分逻辑
        int length = studentAnswer.length();
        if (length > 100) return maxScore;
        if (length > 50) return maxScore * 3 / 4;
        if (length > 20) return maxScore / 2;
        return maxScore / 4;
    }
}