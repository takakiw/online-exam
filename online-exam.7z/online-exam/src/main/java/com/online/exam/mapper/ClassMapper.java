package com.online.exam.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.online.exam.dto.ClassQueryDTO;
import com.online.exam.entity.ClassEntity;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

public interface ClassMapper extends BaseMapper<ClassEntity> {

    @Select("<script>" +
            "SELECT * FROM class WHERE 1=1 " +
            "<if test='dto.keyword != null and dto.keyword != \"\"'>" +
            "   AND (class_name LIKE CONCAT('%', #{dto.keyword}, '%') " +
            "   OR class_code LIKE CONCAT('%', #{dto.keyword}, '%') " +
            "   OR teacher_name LIKE CONCAT('%', #{dto.keyword}, '%'))" +
            "</if>" +
            "<if test='dto.teacherId != null'>" +
            "   AND teacher_id = #{dto.teacherId}" +
            "</if>" +
            "<if test='dto.status != null'>" +
            "   AND status = #{dto.status}" +
            "</if>" +
            " ORDER BY create_time DESC" +
            "</script>")
    Page<ClassEntity> selectClassPage(Page<ClassEntity> page, @Param("dto") ClassQueryDTO dto);

    @Select("SELECT * FROM class WHERE class_code = #{classCode}")
    ClassEntity selectByClassCode(@Param("classCode") String classCode);

    @Select("SELECT * FROM class WHERE invite_code = #{inviteCode}")
    ClassEntity selectByInviteCode(@Param("inviteCode") String inviteCode);

    @Update("UPDATE class SET current_students = current_students + 1 WHERE id = #{classId}")
    int increaseStudentCount(@Param("classId") Long classId);

    @Update("UPDATE class SET current_students = current_students - 1 WHERE id = #{classId}")
    int decreaseStudentCount(@Param("classId") Long classId);
}