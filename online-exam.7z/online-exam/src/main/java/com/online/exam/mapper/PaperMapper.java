package com.online.exam.mapper;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.online.exam.dto.PaperQueryDTO;
import com.online.exam.entity.Paper;
import org.apache.ibatis.annotations.Param;

public interface PaperMapper extends BaseMapper<Paper> {

    default Page<Paper> selectPaperPage(Page<Paper> page, PaperQueryDTO dto) {
        LambdaQueryWrapper<Paper> wrapper = new LambdaQueryWrapper<>();

        if (dto.getKeyword() != null && !dto.getKeyword().isEmpty()) {
            wrapper.like(Paper::getPaperName, dto.getKeyword());
        }
        if (dto.getPaperType() != null && !dto.getPaperType().isEmpty()) {
            wrapper.eq(Paper::getPaperType, dto.getPaperType());
        }
        if (dto.getSubject() != null && !dto.getSubject().isEmpty()) {
            wrapper.eq(Paper::getSubject, dto.getSubject());
        }
        if (dto.getTeacherId() != null) {
            wrapper.eq(Paper::getTeacherId, dto.getTeacherId());
        }
        if (dto.getClassId() != null) {
            wrapper.eq(Paper::getClassId, dto.getClassId());
        }
        if (dto.getStatus() != null) {
            wrapper.eq(Paper::getStatus, dto.getStatus());
        }
        if (dto.getAiJudgeEnabled() != null) {
            wrapper.eq(Paper::getAiJudgeEnabled, dto.getAiJudgeEnabled());
        }

        wrapper.orderByDesc(Paper::getCreateTime);
        return selectPage(page, wrapper);
    }
}