package com.online.exam.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.online.exam.dto.ClassStudentQueryDTO;
import com.online.exam.entity.ClassStudent;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public interface ClassStudentMapper extends BaseMapper<ClassStudent> {

    @Select("<script>" +
            "SELECT * FROM class_student WHERE 1=1 " +
            "<if test='dto.classId != null'>" +
            "   AND class_id = #{dto.classId}" +
            "</if>" +
            "<if test='dto.keyword != null and dto.keyword != \"\"'>" +
            "   AND (student_name LIKE CONCAT('%', #{dto.keyword}, '%') " +
            "   OR student_username LIKE CONCAT('%', #{dto.keyword}, '%'))" +
            "</if>" +
            "<if test='dto.status != null'>" +
            "   AND status = #{dto.status}" +
            "</if>" +
            " ORDER BY join_time DESC" +
            "</script>")
    Page<ClassStudent> selectClassStudentPage(Page<ClassStudent> page, @Param("dto") ClassStudentQueryDTO dto);

    @Select("SELECT * FROM class_student WHERE class_id = #{classId} AND student_id = #{studentId}")
    ClassStudent selectByClassAndStudent(@Param("classId") Long classId, @Param("studentId") Long studentId);

    @Select("SELECT cs.*, c.class_name, c.teacher_name FROM class_student cs " +
            "LEFT JOIN class c ON cs.class_id = c.id " +
            "WHERE cs.student_id = #{studentId} AND cs.status = 1 " +
            "ORDER BY cs.join_time DESC")
    Page<ClassStudent> selectStudentClasses(Page<ClassStudent> page, @Param("studentId") Long studentId);
}