package com.online.exam.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.online.exam.common.AuthContext;
import com.online.exam.common.Constants;
import com.online.exam.dto.*;
import com.online.exam.entity.ClassEntity;
import com.online.exam.entity.ClassStudent;
import com.online.exam.entity.User;
import com.online.exam.mapper.ClassMapper;
import com.online.exam.mapper.ClassStudentMapper;
import com.online.exam.service.ClassService;
import com.online.exam.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.UUID;

@Slf4j
@Service
public class ClassServiceImpl extends ServiceImpl<ClassMapper, ClassEntity> implements ClassService {

    @Autowired
    private ClassStudentMapper classStudentMapper;

    @Autowired
    private UserService userService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ClassEntity createClass(ClassCreateDTO dto, Long teacherId, String teacherName) {
        // 检查教师是否存在
        User teacher = userService.getById(teacherId);
        if (teacher == null) {
            throw new RuntimeException("教师不存在或无权限");
        }

        // 生成班级编码
        String classCode = generateClassCode();

        // 创建班级
        ClassEntity classEntity = new ClassEntity();
        BeanUtils.copyProperties(dto, classEntity);
        classEntity.setTeacherId(teacherId);
        classEntity.setTeacherName(teacherName);
        classEntity.setClassCode(classCode);
        classEntity.setCurrentStudents(0);
        classEntity.setStatus(1);

        save(classEntity);

        // 生成邀请码
        generateInviteCode(classEntity.getId(), 7);

        return classEntity;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateClass(Long classId, ClassUpdateDTO dto) {
        ClassEntity classEntity = getById(classId);
        if (classEntity == null) {
            throw new RuntimeException("班级不存在");
        }

        // 验证权限
        if (!isClassTeacher(classId, AuthContext.getCurrentUserId())) {
            throw new RuntimeException("没有权限修改班级信息");
        }

        if (StringUtils.hasText(dto.getClassName())) {
            classEntity.setClassName(dto.getClassName());
        }
        if (StringUtils.hasText(dto.getDescription())) {
            classEntity.setDescription(dto.getDescription());
        }
        if (dto.getMaxStudents() != null) {
            classEntity.setMaxStudents(dto.getMaxStudents());
        }
        if (dto.getStatus() != null) {
            classEntity.setStatus(dto.getStatus());
        }

        return updateById(classEntity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean deleteClass(Long classId) {
        // 验证权限
        if (!isClassTeacher(classId, AuthContext.getCurrentUserId())) {
            throw new RuntimeException("没有权限删除班级");
        }

        // 删除班级学生关系
        LambdaQueryWrapper<ClassStudent> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ClassStudent::getClassId, classId);
        classStudentMapper.delete(wrapper);

        // 删除班级
        return removeById(classId);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean endClass(Long classId) {
        ClassEntity classEntity = new ClassEntity();
        classEntity.setId(classId);
        classEntity.setStatus(0);
        return updateById(classEntity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean reopenClass(Long classId) {
        ClassEntity classEntity = new ClassEntity();
        classEntity.setId(classId);
        classEntity.setStatus(1);
        return updateById(classEntity);
    }

    @Override
    public Page<ClassEntity> queryClasses(ClassQueryDTO dto) {
        Page<ClassEntity> page = new Page<>(dto.getPageNum(), dto.getPageSize());
        return baseMapper.selectClassPage(page, dto);
    }

    @Override
    public ClassEntity getClassDetail(Long classId) {
        return getById(classId);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String generateInviteCode(Long classId, Integer expireDays) {
        ClassEntity classEntity = getById(classId);
        if (classEntity == null) {
            throw new RuntimeException("班级不存在");
        }

        // 验证权限
        if (!isClassTeacher(classId, AuthContext.getCurrentUserId())) {
            throw new RuntimeException("没有权限生成邀请码");
        }

        // 生成新的邀请码
        String inviteCode = UUID.randomUUID().toString().replaceAll("-", "").substring(0, 8).toUpperCase();
        LocalDateTime expireTime = LocalDateTime.now().plusDays(expireDays);

        classEntity.setInviteCode(inviteCode);
        classEntity.setInviteCodeExpire(expireTime);
        updateById(classEntity);

        return inviteCode;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean disableInviteCode(Long classId) {
        ClassEntity classEntity = getById(classId);
        if (classEntity == null) {
            throw new RuntimeException("班级不存在");
        }

        // 验证权限
        if (!isClassTeacher(classId, AuthContext.getCurrentUserId())) {
            throw new RuntimeException("没有权限禁用邀请码");
        }

        classEntity.setInviteCode(null);
        classEntity.setInviteCodeExpire(null);
        return updateById(classEntity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean joinClass(String inviteCode, Long studentId, String studentName, String studentUsername) {
        // 根据邀请码查找班级
        ClassEntity classEntity = baseMapper.selectByInviteCode(inviteCode);
        if (classEntity == null) {
            throw new RuntimeException("邀请码无效");
        }

        // 检查邀请码是否过期
        if (classEntity.getInviteCodeExpire() != null &&
                classEntity.getInviteCodeExpire().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("邀请码已过期");
        }

        // 检查班级状态
        if (classEntity.getStatus() == 0) {
            throw new RuntimeException("班级已结束");
        }

        // 检查是否已满员
        if (classEntity.getCurrentStudents() >= classEntity.getMaxStudents()) {
            throw new RuntimeException("班级人数已满");
        }

        // 检查是否已加入
        ClassStudent existing = classStudentMapper.selectByClassAndStudent(classEntity.getId(), studentId);
        if (existing != null) {
            if (existing.getStatus() == 1) {
                throw new RuntimeException("已加入该班级");
            } else {
                // 重新加入
                existing.setStatus(1);
                classStudentMapper.updateById(existing);
                baseMapper.increaseStudentCount(classEntity.getId());
                return true;
            }
        }

        // 加入班级
        ClassStudent classStudent = new ClassStudent();
        classStudent.setClassId(classEntity.getId());
        classStudent.setStudentId(studentId);
        classStudent.setStudentName(studentName);
        classStudent.setStudentUsername(studentUsername);
        classStudent.setStatus(1);

        boolean success = classStudentMapper.insert(classStudent) > 0;
        if (success) {
            baseMapper.increaseStudentCount(classEntity.getId());
        }

        return success;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean leaveClass(Long classId, Long studentId) {
        // 检查是否是班级学生
        ClassStudent classStudent = classStudentMapper.selectByClassAndStudent(classId, studentId);
        if (classStudent == null || classStudent.getStatus() == 0) {
            throw new RuntimeException("未加入该班级");
        }

        // 更新状态为已退出
        classStudent.setStatus(0);
        boolean success = classStudentMapper.updateById(classStudent) > 0;
        if (success) {
            baseMapper.decreaseStudentCount(classId);
        }

        return success;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean removeStudent(Long classId, Long studentId) {
        // 验证权限
        if (!isClassTeacher(classId, AuthContext.getCurrentUserId())) {
            throw new RuntimeException("没有权限移除学生");
        }

        // 删除学生关系
        LambdaQueryWrapper<ClassStudent> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ClassStudent::getClassId, classId)
                .eq(ClassStudent::getStudentId, studentId);

        boolean success = classStudentMapper.delete(wrapper) > 0;
        if (success) {
            baseMapper.decreaseStudentCount(classId);
        }

        return success;
    }

    @Override
    public Page<ClassStudent> queryClassStudents(ClassStudentQueryDTO dto) {
        Page<ClassStudent> page = new Page<>(dto.getPageNum(), dto.getPageSize());
        return classStudentMapper.selectClassStudentPage(page, dto);
    }

    @Override
    public Page<ClassStudent> queryStudentClasses(Long studentId, Integer pageNum, Integer pageSize) {
        Page<ClassStudent> page = new Page<>(pageNum, pageSize);
        return classStudentMapper.selectStudentClasses(page, studentId);
    }

    @Override
    public boolean isClassTeacher(Long classId, Long teacherId) {
        if (classId == null || teacherId == null) {
            return false;
        }

        ClassEntity classEntity = getById(classId);
        return classEntity != null && teacherId.equals(classEntity.getTeacherId());
    }

    @Override
    public boolean isClassStudent(Long classId, Long studentId) {
        if (classId == null || studentId == null) {
            return false;
        }

        ClassStudent classStudent = classStudentMapper.selectByClassAndStudent(classId, studentId);
        return classStudent != null && classStudent.getStatus() == 1;
    }

    // 生成班级编码
    private String generateClassCode() {
        String code;
        do {
            code = "C" + System.currentTimeMillis() % 1000000;
        } while (baseMapper.selectByClassCode(code) != null);
        return code;
    }
}