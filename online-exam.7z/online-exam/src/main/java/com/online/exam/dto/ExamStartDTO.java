package com.online.exam.dto;

import lombok.Data;

@Data
public class ExamStartDTO {

    private Long paperId;
}