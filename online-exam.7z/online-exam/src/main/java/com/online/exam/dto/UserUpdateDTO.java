package com.online.exam.dto;

import lombok.Data;

@Data
public class UserUpdateDTO {

    private String nickname;

    private String email;

    private String phone;

    private String avatar;

    private Integer status;

    private String role;
}