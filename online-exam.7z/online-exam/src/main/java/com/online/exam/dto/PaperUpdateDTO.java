package com.online.exam.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class PaperUpdateDTO {

    private String paperName;

    private String description;

    private Integer totalScore;

    private Integer passScore;

    private Integer duration;

    private Integer status;

    private LocalDateTime startTime;

    private LocalDateTime endTime;

    private Boolean aiJudgeEnabled;
}