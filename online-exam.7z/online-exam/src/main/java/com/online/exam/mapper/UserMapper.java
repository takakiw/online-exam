package com.online.exam.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.online.exam.dto.UserQueryDTO;
import com.online.exam.entity.User;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

public interface UserMapper extends BaseMapper<User> {

    @Select("<script>" +
            "SELECT * FROM user WHERE 1=1 " +
            "<if test='dto.keyword != null and dto.keyword != \"\"'>" +
            "   AND (username LIKE CONCAT('%', #{dto.keyword}, '%') " +
            "   OR nickname LIKE CONCAT('%', #{dto.keyword}, '%') " +
            "   OR email LIKE CONCAT('%', #{dto.keyword}, '%') " +
            "   OR phone LIKE CONCAT('%', #{dto.keyword}, '%'))" +
            "</if>" +
            "<if test='dto.role != null and dto.role != \"\"'>" +
            "   AND role = #{dto.role}" +
            "</if>" +
            "<if test='dto.status != null'>" +
            "   AND status = #{dto.status}" +
            "</if>" +
            " ORDER BY create_time DESC" +
            "</script>")
    Page<User> selectUserPage(Page<User> page, @Param("dto") UserQueryDTO dto);

    @Select("SELECT * FROM user WHERE username = #{username}")
    User selectByUsername(@Param("username") String username);

    @Update("UPDATE user SET token = #{token} WHERE id = #{userId}")
    int updateToken(@Param("userId") Long userId, @Param("token") String token);

    @Select("SELECT * FROM user WHERE token = #{token}")
    User selectByToken(@Param("token") String token);
}