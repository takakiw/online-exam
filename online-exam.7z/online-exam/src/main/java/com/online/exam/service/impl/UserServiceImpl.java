package com.online.exam.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.online.exam.common.AuthContext;
import com.online.exam.common.Constants;
import com.online.exam.dto.*;
import com.online.exam.entity.User;
import com.online.exam.entity.UserToken;
import com.online.exam.mapper.UserMapper;
import com.online.exam.service.UserService;
import com.online.exam.util.JwtUtil;
import com.online.exam.util.PasswordUtil;
import com.online.exam.util.SnowflakeIdGenerator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;

@Slf4j
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private PasswordUtil passwordUtil;

    @Autowired
    private SnowflakeIdGenerator idGenerator;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public UserToken login(UserLoginDTO dto) {
        // 验证参数
        if (!StringUtils.hasText(dto.getUsername()) || !StringUtils.hasText(dto.getPassword())) {
            throw new RuntimeException("用户名或密码不能为空");
        }

        // 查询用户
        User user = baseMapper.selectByUsername(dto.getUsername());
        if (user == null) {
            throw new RuntimeException("用户不存在");
        }

        // 检查状态
        if (Constants.USER_STATUS_DISABLED.equals(user.getStatus())) {
            throw new RuntimeException("用户已被禁用");
        }

        // 验证密码（这里简化处理，实际应该加密存储）
        if (!dto.getPassword().equals(user.getPassword())) {
            throw new RuntimeException("密码错误");
        }

        // 生成token
        String token = jwtUtil.generateToken(user.getId(), user.getUsername(), user.getRole());

        // 更新token到数据库
        user.setToken(token);
        baseMapper.updateById(user);

        // 返回token信息
        return new UserToken(user.getId(), user.getUsername(), user.getRole(), token);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean register(UserRegisterDTO dto) {
        // 验证参数
        if (!StringUtils.hasText(dto.getUsername()) || !StringUtils.hasText(dto.getPassword())) {
            throw new RuntimeException("用户名和密码不能为空");
        }

        // 检查密码确认
        if (!dto.getPassword().equals(dto.getConfirmPassword())) {
            throw new RuntimeException("两次输入的密码不一致");
        }

        // 检查用户名是否已存在
        User existingUser = baseMapper.selectByUsername(dto.getUsername());
        if (existingUser != null) {
            throw new RuntimeException("用户名已存在");
        }

        // 创建用户
        User user = new User();
        BeanUtils.copyProperties(dto, user);

        // 设置默认值
        user.setStatus(Constants.USER_STATUS_ENABLED);
        if (!StringUtils.hasText(user.getNickname())) {
            user.setNickname(dto.getUsername());
        }

        // 保存用户
        return save(user);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean logout(String token) {
        try {
            // 从token中获取用户信息
            Long userId = jwtUtil.getUserIdFromToken(token);

            // 清除token
            User user = new User();
            user.setId(userId);
            user.setToken(null);

            return updateById(user);
        } catch (Exception e) {
            log.error("退出登录失败", e);
            return false;
        }
    }

    @Override
    public User getCurrentUser(String token) {
        try {
            if (!StringUtils.hasText(token)) {
                return null;
            }

            // 从数据库查询用户
            return baseMapper.selectByToken(token);
        } catch (Exception e) {
            log.error("获取当前用户失败", e);
            return null;
        }
    }

    @Override
    public Page<User> queryUsers(UserQueryDTO dto) {
        Page<User> page = new Page<>(dto.getPageNum(), dto.getPageSize());
        return baseMapper.selectUserPage(page, dto);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateUser(Long userId, UserUpdateDTO dto) {
        User user = getById(userId);
        if (user == null) {
            throw new RuntimeException("用户不存在");
        }

        // 更新用户信息
        if (StringUtils.hasText(dto.getNickname())) {
            user.setNickname(dto.getNickname());
        }
        if (StringUtils.hasText(dto.getEmail())) {
            user.setEmail(dto.getEmail());
        }
        if (StringUtils.hasText(dto.getPhone())) {
            user.setPhone(dto.getPhone());
        }
        if (StringUtils.hasText(dto.getAvatar())) {
            user.setAvatar(dto.getAvatar());
        }
        if (dto.getStatus() != null) {
            user.setStatus(dto.getStatus());
        }
        if (StringUtils.hasText(dto.getRole())) {
            user.setRole(dto.getRole());
        }

        return updateById(user);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updatePassword(Long userId, PasswordUpdateDTO dto) {
        // 验证参数
        if (!StringUtils.hasText(dto.getOldPassword()) ||
                !StringUtils.hasText(dto.getNewPassword()) ||
                !StringUtils.hasText(dto.getConfirmPassword())) {
            throw new RuntimeException("密码不能为空");
        }

        if (!dto.getNewPassword().equals(dto.getConfirmPassword())) {
            throw new RuntimeException("两次输入的新密码不一致");
        }

        // 获取用户
        User user = getById(userId);
        if (user == null) {
            throw new RuntimeException("用户不存在");
        }

        // 验证原密码（简化处理，实际应该加密验证）
        if (!dto.getOldPassword().equals(user.getPassword())) {
            throw new RuntimeException("原密码错误");
        }

        // 更新密码
        user.setPassword(dto.getNewPassword());
        return updateById(user);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean resetPassword(Long userId) {
        User user = getById(userId);
        if (user == null) {
            throw new RuntimeException("用户不存在");
        }

        // 重置为默认密码
        user.setPassword(Constants.DEFAULT_PASSWORD);
        return updateById(user);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean enableUser(Long userId) {
        User user = new User();
        user.setId(userId);
        user.setStatus(Constants.USER_STATUS_ENABLED);
        return updateById(user);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean disableUser(Long userId) {
        User user = new User();
        user.setId(userId);
        user.setStatus(Constants.USER_STATUS_DISABLED);
        return updateById(user);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean deleteUser(Long userId) {
        // 获取当前登录用户
        Long currentUserId = AuthContext.getCurrentUserId();
        if (currentUserId != null && currentUserId.equals(userId)) {
            throw new RuntimeException("不能删除当前登录用户");
        }

        return removeById(userId);
    }

    @Override
    public User getUserByUsername(String username) {
        return baseMapper.selectByUsername(username);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateUserProfile(Long userId, UserUpdateDTO dto) {
        User user = getById(userId);
        if (user == null) {
            throw new RuntimeException("用户不存在");
        }

        // 只能更新个人资料，不能更新角色和状态
        if (StringUtils.hasText(dto.getNickname())) {
            user.setNickname(dto.getNickname());
        }
        if (StringUtils.hasText(dto.getEmail())) {
            user.setEmail(dto.getEmail());
        }
        if (StringUtils.hasText(dto.getPhone())) {
            user.setPhone(dto.getPhone());
        }
        if (StringUtils.hasText(dto.getAvatar())) {
            user.setAvatar(dto.getAvatar());
        }

        return updateById(user);
    }
}