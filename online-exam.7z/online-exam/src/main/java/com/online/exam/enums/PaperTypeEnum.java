package com.online.exam.enums;

import lombok.Getter;

@Getter
public enum PaperTypeEnum {

    SIMULATION("simulation", "模拟卷"),
    UNIT("unit", "单元卷"),
    EXAM("exam", "考试卷");

    private final String code;
    private final String name;

    PaperTypeEnum(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public static PaperTypeEnum getByCode(String code) {
        for (PaperTypeEnum type : values()) {
            if (type.getCode().equals(code)) {
                return type;
            }
        }
        return SIMULATION;
    }
}