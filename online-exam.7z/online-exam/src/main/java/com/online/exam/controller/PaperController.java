package com.online.exam.controller;

import com.alibaba.fastjson2.JSONObject;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.online.exam.common.AuthContext;
import com.online.exam.common.Result;
import com.online.exam.dto.*;
import com.online.exam.entity.*;
import com.online.exam.enums.ExamStatusEnum;
import com.online.exam.enums.PaperStatusEnum;
import com.online.exam.service.ClassService;
import com.online.exam.service.ExamService;
import com.online.exam.service.PaperService;
import com.online.exam.service.ScoreService;
import com.online.exam.util.DeepSeekUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Validated
@RestController
@RequestMapping("/api/paper")
public class PaperController {

    @Autowired
    private PaperService paperService;

    @Autowired
    private ExamService examService;

    @Autowired
    private ScoreService scoreService;

    @Autowired
    private DeepSeekUtil deepSeekUtil;

    @Autowired
    private ClassService classService;

    // ==================== 试卷管理 ====================

    /**
     * 创建试卷（教师）
     */
    @PostMapping("/create")
    public Result<Paper> createPaper(@Valid @RequestBody PaperCreateDTO dto) {
        try {
            if (!AuthContext.isTeacher()) {
                return Result.error(403, "只有教师可以创建试卷");
            }

            Long teacherId = AuthContext.getCurrentUserId();
            String teacherName = AuthContext.getCurrentUsername();

            Paper paper = paperService.createPaper(dto, teacherId, teacherName);
            return Result.success(paper);
        } catch (Exception e) {
            log.error("创建试卷失败", e);
            return Result.error("创建试卷失败：" + e.getMessage());
        }
    }

    /**
     * 更新试卷信息
     */
    @PutMapping("/update/{paperId}")
    public Result<Boolean> updatePaper(@PathVariable Long paperId, @Valid @RequestBody PaperUpdateDTO dto) {
        try {
            boolean success = paperService.updatePaper(paperId, dto);
            return success ? Result.success(true) : Result.error("更新试卷失败");
        } catch (Exception e) {
            log.error("更新试卷失败", e);
            return Result.error("更新试卷失败：" + e.getMessage());
        }
    }

    /**
     * 删除试卷
     */
    @DeleteMapping("/delete/{paperId}")
    public Result<Boolean> deletePaper(@PathVariable Long paperId) {
        try {
            boolean success = paperService.deletePaper(paperId);
            return success ? Result.success(true) : Result.error("删除试卷失败");
        } catch (Exception e) {
            log.error("删除试卷失败", e);
            return Result.error("删除试卷失败：" + e.getMessage());
        }
    }

    /**
     * 发布试卷
     */
    @PutMapping("/publish/{paperId}")
    public Result<Boolean> publishPaper(@PathVariable Long paperId) {
        try {
            if (!AuthContext.isTeacher()) {
                return Result.error(403, "只有教师可以发布试卷");
            }

            boolean success = paperService.publishPaper(paperId);
            return success ? Result.success(true) : Result.error("发布试卷失败");
        } catch (Exception e) {
            log.error("发布试卷失败", e);
            return Result.error("发布试卷失败：" + e.getMessage());
        }
    }

    /**
     * 结束试卷
     */
    @PutMapping("/end/{paperId}")
    public Result<Boolean> endPaper(@PathVariable Long paperId) {
        try {
            if (!AuthContext.isTeacher()) {
                return Result.error(403, "只有教师可以结束试卷");
            }

            boolean success = paperService.endPaper(paperId);
            return success ? Result.success(true) : Result.error("结束试卷失败");
        } catch (Exception e) {
            log.error("结束试卷失败", e);
            return Result.error("结束试卷失败：" + e.getMessage());
        }
    }

    /**
     * 查询试卷详情
     */
    @GetMapping("/detail/{paperId}")
    public Result<Paper> getPaperDetail(@PathVariable Long paperId) {
        try {
            Paper paper = paperService.getPaperDetail(paperId);
            if (paper == null) {
                return Result.error(404, "试卷不存在");
            }
            return Result.success(paper);
        } catch (Exception e) {
            log.error("查询试卷详情失败", e);
            return Result.error("查询试卷详情失败：" + e.getMessage());
        }
    }

    /**
     * 分页查询试卷列表
     */
    @PostMapping("/query")
    public Result<Page<Paper>> queryPapers(@Valid @RequestBody PaperQueryDTO dto) {
        try {
            // 如果不是管理员或教师，只能查询已发布的试卷
            if (AuthContext.isStudent()) {
                dto.setStatus(PaperStatusEnum.PUBLISHED.getCode());
            }

            Page<Paper> page = paperService.queryPapers(dto);
            return Result.success(page, page.getTotal());
        } catch (Exception e) {
            log.error("查询试卷列表失败", e);
            return Result.error("查询试卷列表失败：" + e.getMessage());
        }
    }

    /**
     * 查询我创建的试卷（教师）
     */
    @GetMapping("/my-teacher-papers")
    public Result<Page<Paper>> getMyTeacherPapers(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize) {
        try {
            if (!AuthContext.isTeacher()) {
                return Result.error(403, "只有教师可以查看创建的试卷");
            }

            PaperQueryDTO dto = new PaperQueryDTO();
            dto.setTeacherId(AuthContext.getCurrentUserId());
            dto.setPageNum(pageNum);
            dto.setPageSize(pageSize);

            Page<Paper> page = paperService.queryPapers(dto);
            return Result.success(page, page.getTotal());
        } catch (Exception e) {
            log.error("查询我创建的试卷失败", e);
            return Result.error("查询我创建的试卷失败：" + e.getMessage());
        }
    }

    /**
     * 查询班级试卷（学生）
     */
    @GetMapping("/class-papers/{classId}")
    public Result<Page<Paper>> getClassPapers(
            @PathVariable Long classId,
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize) {
        try {
            Page<Paper> page = paperService.queryClassPapers(classId, pageNum, pageSize);

            // 学生只能看到已发布的试卷
            if (AuthContext.isStudent()) {
                page.getRecords().removeIf(paper ->
                        !PaperStatusEnum.PUBLISHED.getCode().equals(paper.getStatus()));
            }

            return Result.success(page, page.getTotal());
        } catch (Exception e) {
            log.error("查询班级试卷失败", e);
            return Result.error("查询班级试卷失败：" + e.getMessage());
        }
    }

    // ==================== 试卷题目管理 ====================

    /**
     * 添加题目到试卷
     */
    @PostMapping("/question/add")
    public Result<Boolean> addQuestionToPaper(@Valid @RequestBody PaperQuestionDTO dto) {
        try {
            if (!AuthContext.isTeacher()) {
                return Result.error(403, "只有教师可以添加题目到试卷");
            }

            boolean success = paperService.addQuestionToPaper(dto);
            return success ? Result.success(true) : Result.error("添加题目失败");
        } catch (Exception e) {
            log.error("添加题目到试卷失败", e);
            return Result.error("添加题目到试卷失败：" + e.getMessage());
        }
    }

    /**
     * 从试卷中移除题目
     */
    @DeleteMapping("/question/remove/{paperId}/{questionId}")
    public Result<Boolean> removeQuestionFromPaper(@PathVariable Long paperId,
                                                   @PathVariable Long questionId) {
        try {
            if (!AuthContext.isTeacher()) {
                return Result.error(403, "只有教师可以从试卷中移除题目");
            }

            boolean success = paperService.removeQuestionFromPaper(paperId, questionId);
            return success ? Result.success(true) : Result.error("移除题目失败");
        } catch (Exception e) {
            log.error("从试卷中移除题目失败", e);
            return Result.error("从试卷中移除题目失败：" + e.getMessage());
        }
    }

    /**
     * 更新题目分值
     */
    @PutMapping("/question/score/{paperId}/{questionId}")
    public Result<Boolean> updateQuestionScore(@PathVariable Long paperId,
                                               @PathVariable Long questionId,
                                               @RequestParam Integer score) {
        try {
            if (!AuthContext.isTeacher()) {
                return Result.error(403, "只有教师可以修改题目分值");
            }

            boolean success = paperService.updateQuestionScore(paperId, questionId, score);
            return success ? Result.success(true) : Result.error("更新题目分值失败");
        } catch (Exception e) {
            log.error("更新题目分值失败", e);
            return Result.error("更新题目分值失败：" + e.getMessage());
        }
    }

    /**
     * 查询试卷题目列表
     */
    @GetMapping("/questions/{paperId}")
    public Result<List<PaperQuestion>> getPaperQuestions(@PathVariable Long paperId) {
        try {
            // 权限检查：教师可以查看所有，学生只能查看已发布的试卷
            Paper paper = paperService.getPaperDetail(paperId);
            if (paper == null) {
                return Result.error(404, "试卷不存在");
            }

            if (AuthContext.isStudent() &&
                    !PaperStatusEnum.PUBLISHED.getCode().equals(paper.getStatus())) {
                return Result.error(403, "没有权限查看该试卷题目");
            }

            List<PaperQuestion> questions = paperService.getPaperQuestions(paperId);
            return Result.success(questions);
        } catch (Exception e) {
            log.error("查询试卷题目列表失败", e);
            return Result.error("查询试卷题目列表失败：" + e.getMessage());
        }
    }

    /**
     * 分页查询试卷题目
     */
    @GetMapping("/questions/page/{paperId}")
    public Result<Page<PaperQuestion>> getPaperQuestionsPage(
            @PathVariable Long paperId,
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize) {
        try {
            // 权限检查
            Paper paper = paperService.getPaperDetail(paperId);
            if (paper == null) {
                return Result.error(404, "试卷不存在");
            }

            if (AuthContext.isStudent() &&
                    !PaperStatusEnum.PUBLISHED.getCode().equals(paper.getStatus())) {
                return Result.error(403, "没有权限查看该试卷题目");
            }

            Page<PaperQuestion> page = paperService.getPaperQuestionsPage(paperId, pageNum, pageSize);
            return Result.success(page, page.getTotal());
        } catch (Exception e) {
            log.error("分页查询试卷题目失败", e);
            return Result.error("分页查询试卷题目失败：" + e.getMessage());
        }
    }

    // ==================== 试卷生成 ====================

    /**
     * 根据规则生成试卷
     */
    @PostMapping("/generate/{paperId}")
    public Result<Boolean> generatePaper(@PathVariable Long paperId,
                                         @RequestBody PaperRuleDTO rule) {
        try {
            if (!AuthContext.isTeacher()) {
                return Result.error(403, "只有教师可以生成试卷");
            }

            boolean success = paperService.generatePaper(paperId, rule);
            return success ? Result.success(true) : Result.error("生成试卷失败");
        } catch (Exception e) {
            log.error("生成试卷失败", e);
            return Result.error("生成试卷失败：" + e.getMessage());
        }
    }

    /**
     * 自动生成试卷（按策略）
     */
    @PostMapping("/auto-generate/{paperId}")
    public Result<Boolean> autoGeneratePaper(@PathVariable Long paperId,
                                             @RequestParam String strategy) {
        try {
            if (!AuthContext.isTeacher()) {
                return Result.error(403, "只有教师可以生成试卷");
            }

            boolean success = paperService.autoGeneratePaper(paperId, strategy);
            return success ? Result.success(true) : Result.error("自动生成试卷失败");
        } catch (Exception e) {
            log.error("自动生成试卷失败", e);
            return Result.error("自动生成试卷失败：" + e.getMessage());
        }
    }

    /**
     * 保存试卷（学生保存未完成的试卷）
     */
    @PostMapping("/save/{paperId}")
    public Result<Boolean> savePaper(@PathVariable Long paperId) {
        try {
            if (!AuthContext.isStudent()) {
                return Result.error(403, "只有学生可以保存试卷");
            }

            Long studentId = AuthContext.getCurrentUserId();

            // 检查学生是否有进行中的考试
            ExamQueryDTO examQuery = new ExamQueryDTO();
            examQuery.setPaperId(paperId);
            examQuery.setStudentId(studentId);
            examQuery.setStatus(0); // 进行中

            Page<ExamRecord> examPage = examService.queryExamRecords(examQuery);
            if (examPage.getRecords().isEmpty()) {
                return Result.error("没有找到进行中的考试记录");
            }

            ExamRecord examRecord = examPage.getRecords().get(0);

            // 保存考试记录（实际上已经在考试过程中自动保存）
            // 这里主要是更新最后保存时间或标记为已保存状态
            log.info("学生保存试卷，学生ID：{}，试卷ID：{}，考试记录ID：{}",
                    studentId, paperId, examRecord.getId());

            return Result.success(true);
        } catch (Exception e) {
            log.error("保存试卷失败", e);
            return Result.error("保存试卷失败：" + e.getMessage());
        }
    }

    /**
     * 查询试卷记录（学生查看自己的考试记录）
     */
    @GetMapping("/records/{paperId}")
    public Result<Page<ExamRecord>> getPaperRecords(@PathVariable Long paperId,
                                                    @RequestParam(defaultValue = "1") Integer pageNum,
                                                    @RequestParam(defaultValue = "10") Integer pageSize) {
        try {
            if (!AuthContext.isStudent()) {
                return Result.error(403, "只有学生可以查看试卷记录");
            }

            Long studentId = AuthContext.getCurrentUserId();

            ExamQueryDTO examQuery = new ExamQueryDTO();
            examQuery.setPaperId(paperId);
            examQuery.setStudentId(studentId);
            examQuery.setPageNum(pageNum);
            examQuery.setPageSize(pageSize);

            Page<ExamRecord> page = examService.queryExamRecords(examQuery);

            // 对每一条记录添加更多信息
            page.getRecords().forEach(record -> {
                // 获取考试成绩
                ExamScore score = scoreService.getScoreDetail(record.getId());
                if (score != null) {
                    record.setScore(score.getScore());
                    record.setIsPassed(score.getIsPassed());
                }
            });

            return Result.success(page, page.getTotal());
        } catch (Exception e) {
            log.error("查询试卷记录失败", e);
            return Result.error("查询试卷记录失败：" + e.getMessage());
        }
    }

    /**
     * 查询试题详情（学生查看答案解析）
     */
    @GetMapping("/question/detail/{paperId}/{questionId}")
    public Result<PaperQuestion> getQuestionDetail(@PathVariable Long paperId,
                                                   @PathVariable Long questionId) {
        try {

            Long studentId = AuthContext.getCurrentUserId();

            // 检查学生是否有已提交或已判卷的该试卷考试记录
            ExamQueryDTO examQuery = new ExamQueryDTO();
            examQuery.setPaperId(paperId);
            examQuery.setStudentId(studentId);
            examQuery.setStatus(1); // 已提交

            Page<ExamRecord> examPage = examService.queryExamRecords(examQuery);
            if (examPage.getRecords().isEmpty()) {
                // 如果没有已提交的记录，检查已判卷的记录
                examQuery.setStatus(2); // 已判卷
                examPage = examService.queryExamRecords(examQuery);
                if (examPage.getRecords().isEmpty()) {
                    return Result.error("请先完成并提交该试卷");
                }
            }

            // 获取试卷题目
            List<PaperQuestion> paperQuestions = paperService.getPaperQuestions(paperId);
            PaperQuestion paperQuestion = paperQuestions.stream()
                    .filter(q -> q.getQuestionId().equals(questionId))
                    .findFirst()
                    .orElse(null);

            if (paperQuestion == null) {
                return Result.error(404, "题目不存在");
            }

            // 获取学生的答案
            ExamRecord examRecord = examPage.getRecords().get(0);
            ExamAnswer examAnswer = examService.getExamAnswer(examRecord.getId(), questionId);

            // 如果教师开启了AI解析，并且题目没有解析，则调用AI解析
            Paper paper = paperService.getById(paperId);
            if (paper != null && paper.getAiJudgeEnabled() &&
                    (paperQuestion.getQuestionAnalysis() == null ||
                            paperQuestion.getQuestionAnalysis().isEmpty())) {

                String aiAnalysis = deepSeekUtil.analyzeQuestion(
                        paperQuestion.getQuestionContent(),
                        paperQuestion.getQuestionAnswer()
                );
                paperQuestion.setQuestionAnalysis(aiAnalysis);
            }

            // 添加学生答案信息
            if (examAnswer != null) {
                // 创建增强的返回对象
                PaperQuestion enhancedQuestion = new PaperQuestion();
                enhancedQuestion.setId(paperQuestion.getId());
                enhancedQuestion.setPaperId(paperQuestion.getPaperId());
                enhancedQuestion.setQuestionId(paperQuestion.getQuestionId());
                enhancedQuestion.setQuestionContent(paperQuestion.getQuestionContent());
                enhancedQuestion.setQuestionType(paperQuestion.getQuestionType());
                enhancedQuestion.setQuestionOptions(paperQuestion.getQuestionOptions());
                enhancedQuestion.setQuestionAnswer(paperQuestion.getQuestionAnswer());
                enhancedQuestion.setQuestionAnalysis(paperQuestion.getQuestionAnalysis());
                enhancedQuestion.setQuestionDifficulty(paperQuestion.getQuestionDifficulty());
                enhancedQuestion.setQuestionScore(paperQuestion.getQuestionScore());
                enhancedQuestion.setSortOrder(paperQuestion.getSortOrder());

                // 添加额外信息
                JSONObject extraInfo = new JSONObject();
                extraInfo.put("studentAnswer", examAnswer.getStudentAnswer());
                extraInfo.put("studentScore", examAnswer.getStudentScore());
                extraInfo.put("isCorrect", examAnswer.getIsCorrect());
                extraInfo.put("aiJudgeResult", examAnswer.getAiJudgeResult());

                // 如果是主观题且开启了AI判卷，添加AI评语
                if ("subjective".equals(paperQuestion.getQuestionType()) &&
                        paper.getAiJudgeEnabled() &&
                        examAnswer.getAiJudgeResult() != null) {
                    try {
                        JSONObject aiResult = JSONObject.parseObject(examAnswer.getAiJudgeResult());
                        extraInfo.put("aiComment", aiResult.getString("comment"));
                        extraInfo.put("aiSuggestions", aiResult.getString("suggestions"));
                    } catch (Exception e) {
                        log.warn("解析AI判卷结果失败", e);
                    }
                }

                enhancedQuestion.setExtraInfo(extraInfo);
                paperQuestion = enhancedQuestion;
            }

            return Result.success(paperQuestion);
        } catch (Exception e) {
            log.error("查询试题详情失败", e);
            return Result.error("查询试题详情失败：" + e.getMessage());
        }
    }

    /**
     * 查询试卷统计信息（教师）
     */
    @GetMapping("/statistics/{paperId}")
    public Result<JSONObject> getPaperStatistics(@PathVariable Long paperId) {
        try {
            if (!AuthContext.isTeacher()) {
                return Result.error(403, "只有教师可以查看试卷统计");
            }

            Paper paper = paperService.getById(paperId);
            if (paper == null) {
                return Result.error(404, "试卷不存在");
            }

            // 验证权限：只能查看自己创建的试卷
            if (!paper.getTeacherId().equals(AuthContext.getCurrentUserId())) {
                return Result.error(403, "没有权限查看该试卷统计");
            }

            JSONObject statistics = new JSONObject();

            // 1. 试卷基本信息
            statistics.put("paperName", paper.getPaperName());
            statistics.put("paperType", paper.getPaperType());
            statistics.put("totalScore", paper.getTotalScore());
            statistics.put("passScore", paper.getPassScore());
            statistics.put("duration", paper.getDuration());
            statistics.put("status", paper.getStatus());
            statistics.put("aiJudgeEnabled", paper.getAiJudgeEnabled());

            // 2. 题目统计
            List<PaperQuestion> questions = paperService.getPaperQuestions(paperId);
            statistics.put("questionCount", questions.size());

            // 按题型统计
            JSONObject typeStatistics = new JSONObject();
            questions.stream()
                    .collect(Collectors.groupingBy(PaperQuestion::getQuestionType, Collectors.counting()))
                    .forEach(typeStatistics::put);
            statistics.put("typeStatistics", typeStatistics);

            // 按难度统计
            JSONObject difficultyStatistics = new JSONObject();
            questions.stream()
                    .collect(Collectors.groupingBy(PaperQuestion::getQuestionDifficulty, Collectors.counting()))
                    .entrySet().forEach(entry -> {
                Integer difficulty = entry.getKey();
                Long count = entry.getValue();
                difficultyStatistics.put(difficulty.toString(), count);
            });
            statistics.put("difficultyStatistics", difficultyStatistics);

            // 3. 考试情况统计
            ExamQueryDTO examQuery = new ExamQueryDTO();
            examQuery.setPaperId(paperId);

            // 获取所有考试记录
            Page<ExamRecord> examPage = examService.queryExamRecords(examQuery);
            List<ExamRecord> examRecords = examPage.getRecords();

            statistics.put("totalExamCount", examRecords.size());

            // 按状态统计
            JSONObject statusStatistics = new JSONObject();
            examRecords.stream()
                    .collect(Collectors.groupingBy(ExamRecord::getStatus, Collectors.counting()))
                    .entrySet().forEach(entry -> {
                Integer status = entry.getKey();
                Long count = entry.getValue();
                statusStatistics.put(status.toString(), count);
            });
            statistics.put("examStatusStatistics", statusStatistics);

            // 4. 成绩统计（仅针对已判卷的考试）
            List<ExamRecord> judgedExams = examRecords.stream()
                    .filter(record -> ExamStatusEnum.JUDGED.getCode().equals(record.getStatus()))
                    .collect(Collectors.toList());

            if (!judgedExams.isEmpty()) {
                int totalScoreSum = judgedExams.stream().mapToInt(ExamRecord::getScore).sum();
                int maxScore = judgedExams.stream().mapToInt(ExamRecord::getScore).max().orElse(0);
                int minScore = judgedExams.stream().mapToInt(ExamRecord::getScore).min().orElse(0);
                long passedCount = judgedExams.stream().filter(ExamRecord::getIsPassed).count();

                statistics.put("averageScore", (double) totalScoreSum / judgedExams.size());
                statistics.put("maxScore", maxScore);
                statistics.put("minScore", minScore);
                statistics.put("passedCount", passedCount);
                statistics.put("passedRate", (double) passedCount / judgedExams.size() * 100);

                // 分数段统计
                JSONObject scoreDistribution = new JSONObject();
                judgedExams.stream()
                        .collect(Collectors.groupingBy(
                                record -> getScoreRange(record.getScore(), paper.getTotalScore()),
                                Collectors.counting()
                        ))
                        .forEach(scoreDistribution::put);
                statistics.put("scoreDistribution", scoreDistribution);
            }

            // 5. 班级参与情况（如果试卷属于班级）
            if (paper.getClassId() != null) {
                ClassEntity classEntity = classService.getById(paper.getClassId());
                if (classEntity != null) {
                    JSONObject classInfo = new JSONObject();
                    classInfo.put("className", classEntity.getClassName());
                    classInfo.put("studentCount", classEntity.getCurrentStudents());
                    classInfo.put("examParticipantCount", examRecords.size());
                    classInfo.put("participationRate",
                            (double) examRecords.size() / classEntity.getCurrentStudents() * 100);
                    statistics.put("classInfo", classInfo);
                }
            }

            return Result.success(statistics);
        } catch (Exception e) {
            log.error("查询试卷统计失败", e);
            return Result.error("查询试卷统计失败：" + e.getMessage());
        }
    }

    /**
     * 复制试卷（教师）
     */
    @PostMapping("/copy/{paperId}")
    public Result<Paper> copyPaper(@PathVariable Long paperId,
                                   @RequestParam(required = false) String newPaperName) {
        try {
            if (!AuthContext.isTeacher()) {
                return Result.error(403, "只有教师可以复制试卷");
            }

            Paper originalPaper = paperService.getById(paperId);
            if (originalPaper == null) {
                return Result.error(404, "原试卷不存在");
            }

            // 验证权限：只能复制自己创建的试卷
            if (!originalPaper.getTeacherId().equals(AuthContext.getCurrentUserId())) {
                return Result.error(403, "只能复制自己创建的试卷");
            }

            // 创建新试卷
            PaperCreateDTO createDTO = new PaperCreateDTO();
            createDTO.setPaperName(newPaperName != null ? newPaperName :
                    originalPaper.getPaperName() + " (副本)");
            createDTO.setPaperType(originalPaper.getPaperType());
            createDTO.setDescription(originalPaper.getDescription());
            createDTO.setSubject(originalPaper.getSubject());
            createDTO.setTotalScore(originalPaper.getTotalScore());
            createDTO.setPassScore(originalPaper.getPassScore());
            createDTO.setDuration(originalPaper.getDuration());
            createDTO.setClassId(originalPaper.getClassId());
            createDTO.setGenerateStrategy(originalPaper.getGenerateStrategy());
            createDTO.setAiJudgeEnabled(originalPaper.getAiJudgeEnabled());

            Paper newPaper = paperService.createPaper(createDTO,
                    AuthContext.getCurrentUserId(),
                    AuthContext.getCurrentUsername());

            // 复制题目
            List<PaperQuestion> originalQuestions = paperService.getPaperQuestions(paperId);
            for (PaperQuestion question : originalQuestions) {
                PaperQuestionDTO questionDTO = new PaperQuestionDTO();
                questionDTO.setPaperId(newPaper.getId());
                questionDTO.setQuestionId(question.getQuestionId());
                questionDTO.setQuestionScore(question.getQuestionScore());
                questionDTO.setSortOrder(question.getSortOrder());

                paperService.addQuestionToPaper(questionDTO);
            }

            log.info("试卷复制成功，原试卷ID：{}，新试卷ID：{}", paperId, newPaper.getId());
            return Result.success(newPaper);
        } catch (Exception e) {
            log.error("复制试卷失败", e);
            return Result.error("复制试卷失败：" + e.getMessage());
        }
    }

    /**
     * 导出试卷（教师）
     */
    @GetMapping("/export/{paperId}")
    public Result<JSONObject> exportPaper(@PathVariable Long paperId,
                                          @RequestParam(defaultValue = "json") String format) {
        try {
            if (!AuthContext.isTeacher()) {
                return Result.error(403, "只有教师可以导出试卷");
            }

            Paper paper = paperService.getById(paperId);
            if (paper == null) {
                return Result.error(404, "试卷不存在");
            }

            // 验证权限：只能导出自己创建的试卷
            if (!paper.getTeacherId().equals(AuthContext.getCurrentUserId())) {
                return Result.error(403, "只能导出自己创建的试卷");
            }

            JSONObject exportData = new JSONObject();

            // 1. 试卷基本信息
            exportData.put("paper", paper);

            // 2. 试卷题目
            List<PaperQuestion> questions = paperService.getPaperQuestions(paperId);
            exportData.put("questions", questions);

            // 3. 如果是JSON格式，直接返回
            if ("json".equalsIgnoreCase(format)) {
                return Result.success(exportData);
            }

            // 4. 如果是其他格式（如PDF、Word），这里可以扩展
            // 实际项目中，这里会调用相应的导出服务

            log.info("试卷导出成功，试卷ID：{}，格式：{}", paperId, format);
            return Result.success(exportData);
        } catch (Exception e) {
            log.error("导出试卷失败", e);
            return Result.error("导出试卷失败：" + e.getMessage());
        }
    }

    /**
     * 批量操作试卷（教师）
     */
    @PostMapping("/batch")
    public Result<JSONObject> batchOperation(@RequestBody JSONObject operation) {
        try {
            if (!AuthContext.isTeacher()) {
                return Result.error(403, "只有教师可以进行批量操作");
            }

            String operationType = operation.getString("type");
            List<Long> paperIds = operation.getJSONArray("paperIds").toJavaList(Long.class);

            if (paperIds == null || paperIds.isEmpty()) {
                return Result.error("请选择要操作的试卷");
            }

            int successCount = 0;
            int failCount = 0;

            for (Long paperId : paperIds) {
                try {
                    Paper paper = paperService.getById(paperId);
                    if (paper == null || !paper.getTeacherId().equals(AuthContext.getCurrentUserId())) {
                        failCount++;
                        continue;
                    }

                    switch (operationType) {
                        case "publish":
                            paperService.publishPaper(paperId);
                            successCount++;
                            break;
                        case "end":
                            paperService.endPaper(paperId);
                            successCount++;
                            break;
                        case "delete":
                            paperService.deletePaper(paperId);
                            successCount++;
                            break;
                        default:
                            failCount++;
                    }
                } catch (Exception e) {
                    log.error("批量操作试卷失败，试卷ID：{}", paperId, e);
                    failCount++;
                }
            }

            JSONObject result = new JSONObject();
            result.put("successCount", successCount);
            result.put("failCount", failCount);
            result.put("totalCount", paperIds.size());

            return Result.success(result);
        } catch (Exception e) {
            log.error("批量操作试卷失败", e);
            return Result.error("批量操作试卷失败：" + e.getMessage());
        }
    }

    /**
     * 查询试卷题目数量统计
     */
    @GetMapping("/question-count/{paperId}")
    public Result<JSONObject> getQuestionCount(@PathVariable Long paperId) {
        try {
            Paper paper = paperService.getById(paperId);
            if (paper == null) {
                return Result.error(404, "试卷不存在");
            }

            // 权限检查
            if (AuthContext.isStudent() &&
                    !PaperStatusEnum.PUBLISHED.getCode().equals(paper.getStatus())) {
                return Result.error(403, "没有权限查看该试卷");
            }

            List<PaperQuestion> questions = paperService.getPaperQuestions(paperId);

            JSONObject countInfo = new JSONObject();
            countInfo.put("totalCount", questions.size());
            countInfo.put("totalScore", paper.getTotalScore());

            // 按题型统计
            JSONObject typeCount = new JSONObject();
            questions.stream()
                    .collect(Collectors.groupingBy(PaperQuestion::getQuestionType, Collectors.counting()))
                    .forEach(typeCount::put);
            countInfo.put("typeCount", typeCount);

            return Result.success(countInfo);
        } catch (Exception e) {
            log.error("查询试卷题目数量失败", e);
            return Result.error("查询试卷题目数量失败：" + e.getMessage());
        }
    }

    // ==================== 辅助方法 ====================

    private String getScoreRange(Integer score, Integer totalScore) {
        if (score == null || totalScore == null || totalScore == 0) {
            return "未知";
        }

        double percentage = (double) score / totalScore * 100;
        if (percentage >= 90) return "90-100";
        if (percentage >= 80) return "80-89";
        if (percentage >= 70) return "70-79";
        if (percentage >= 60) return "60-69";
        return "0-59";
    }
}