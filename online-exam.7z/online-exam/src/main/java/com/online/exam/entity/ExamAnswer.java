package com.online.exam.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("exam_answer")
public class ExamAnswer implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @TableField("exam_record_id")
    private Long examRecordId;

    @TableField("paper_id")
    private Long paperId;

    @TableField("question_id")
    private Long questionId;

    @TableField("student_id")
    private Long studentId;

    @TableField("student_answer")
    private String studentAnswer;

    @TableField("correct_answer")
    private String correctAnswer;

    @TableField("question_score")
    private Integer questionScore;

    @TableField("student_score")
    private Integer studentScore;

    @TableField("is_correct")
    private Boolean isCorrect;

    @TableField("ai_judge_result")
    private String aiJudgeResult;

    @TableField(value = "create_time", fill = FieldFill.INSERT)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;
}