package com.online.exam.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.online.exam.common.AuthContext;
import com.online.exam.common.Result;
import com.online.exam.dto.*;
import com.online.exam.entity.User;
import com.online.exam.entity.UserToken;
import com.online.exam.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.List;

@Slf4j
@Validated
@RestController
@RequestMapping("/api/user")
public class UserController {

    @Autowired
    private UserService userService;

    /**
     * 用户登录
     */
    @PostMapping("/login")
    public Result<UserToken> login(@Valid @RequestBody UserLoginDTO dto) {
        try {
            UserToken token = userService.login(dto);
            return Result.success(token);
        } catch (Exception e) {
            log.error("用户登录失败", e);
            return Result.error("登录失败：" + e.getMessage());
        }
    }

    /**
     * 用户注册
     */
    @PostMapping("/register")
    public Result<Boolean> register(@Valid @RequestBody UserRegisterDTO dto) {
        try {
            boolean success = userService.register(dto);
            if (success) {
                return Result.success(true);
            } else {
                return Result.error("注册失败");
            }
        } catch (Exception e) {
            log.error("用户注册失败", e);
            return Result.error("注册失败：" + e.getMessage());
        }
    }

    /**
     * 用户退出登录
     */
    @PostMapping("/logout")
    public Result<Boolean> logout(HttpServletRequest request) {
        try {
            String token = extractToken(request);
            if (token == null) {
                return Result.error("token不能为空");
            }

            boolean success = userService.logout(token);
            if (success) {
                return Result.success(true);
            } else {
                return Result.error("退出登录失败");
            }
        } catch (Exception e) {
            log.error("用户退出登录失败", e);
            return Result.error("退出登录失败：" + e.getMessage());
        }
    }

    /**
     * 获取当前用户信息
     */
    @GetMapping("/current")
    public Result<User> getCurrentUser(HttpServletRequest request) {
        try {
            String token = extractToken(request);
            if (token == null) {
                return Result.error(401, "未登录");
            }

            User user = userService.getCurrentUser(token);
            if (user == null) {
                return Result.error(401, "用户不存在或token已过期");
            }

            // 隐藏密码
            user.setPassword(null);
            return Result.success(user);
        } catch (Exception e) {
            log.error("获取当前用户信息失败", e);
            return Result.error("获取用户信息失败：" + e.getMessage());
        }
    }

    /**
     * 分页查询用户
     */
    @PostMapping("/query")
    public Result<Page<User>> queryUsers(@Valid @RequestBody UserQueryDTO dto) {
        try {
            // 只有管理员和教师可以查询用户
            String role = AuthContext.getCurrentRole();
            if (!("admin".equals(role) || "teacher".equals(role))) {
                return Result.error(403, "没有权限查询用户列表");
            }

            Page<User> page = userService.queryUsers(dto);

            // 隐藏所有用户的密码
            page.getRecords().forEach(user -> user.setPassword(null));

            return Result.success(page, page.getTotal());
        } catch (Exception e) {
            log.error("查询用户列表失败", e);
            return Result.error("查询用户列表失败：" + e.getMessage());
        }
    }

    /**
     * 根据ID查询用户
     */
    @GetMapping("/{id}")
    public Result<User> getUserById(@PathVariable Long id) {
        try {
            User user = userService.getById(id);
            if (user == null) {
                return Result.error(404, "用户不存在");
            }

            // 隐藏密码
            user.setPassword(null);
            user.setToken(null);
            return Result.success(user);
        } catch (Exception e) {
            log.error("查询用户详情失败", e);
            return Result.error("查询用户详情失败：" + e.getMessage());
        }
    }

    /**
     * 更新用户信息（管理员用）
     */
    @PutMapping("/update/{id}")
    public Result<Boolean> updateUser(@PathVariable Long id, @Valid @RequestBody UserUpdateDTO dto) {
        try {
            // 检查权限
            if (!AuthContext.isAdmin()) {
                return Result.error(403, "只有管理员可以更新用户信息");
            }

            boolean success = userService.updateUser(id, dto);
            if (success) {
                return Result.success(true);
            } else {
                return Result.error("更新用户失败");
            }
        } catch (Exception e) {
            log.error("更新用户失败", e);
            return Result.error("更新用户失败：" + e.getMessage());
        }
    }

    /**
     * 更新个人资料
     */
    @PutMapping("/profile")
    public Result<Boolean> updateProfile(@Valid @RequestBody UserUpdateDTO dto, HttpServletRequest request) {
        try {
            String token = extractToken(request);
            if (token == null) {
                return Result.error(401, "未登录");
            }

            User user = userService.getCurrentUser(token);
            if (user == null) {
                return Result.error(401, "用户不存在或token已过期");
            }

            boolean success = userService.updateUserProfile(user.getId(), dto);
            if (success) {
                return Result.success(true);
            } else {
                return Result.error("更新个人资料失败");
            }
        } catch (Exception e) {
            log.error("更新个人资料失败", e);
            return Result.error("更新个人资料失败：" + e.getMessage());
        }
    }

    /**
     * 修改密码
     */
    @PutMapping("/password")
    public Result<Boolean> updatePassword(@Valid @RequestBody PasswordUpdateDTO dto, HttpServletRequest request) {
        try {
            String token = extractToken(request);
            if (token == null) {
                return Result.error(401, "未登录");
            }

            User user = userService.getCurrentUser(token);
            if (user == null) {
                return Result.error(401, "用户不存在或token已过期");
            }

            boolean success = userService.updatePassword(user.getId(), dto);
            if (success) {
                return Result.success(true);
            } else {
                return Result.error("修改密码失败");
            }
        } catch (Exception e) {
            log.error("修改密码失败", e);
            return Result.error("修改密码失败：" + e.getMessage());
        }
    }

    /**
     * 重置用户密码（管理员用）
     */
    @PutMapping("/reset-password/{id}")
    public Result<Boolean> resetPassword(@PathVariable Long id) {
        try {
            // 检查权限
            if (!AuthContext.isAdmin()) {
                return Result.error(403, "只有管理员可以重置用户密码");
            }

            boolean success = userService.resetPassword(id);
            if (success) {
                return Result.success(true);
            } else {
                return Result.error("重置密码失败");
            }
        } catch (Exception e) {
            log.error("重置密码失败", e);
            return Result.error("重置密码失败：" + e.getMessage());
        }
    }

    /**
     * 启用用户
     */
    @PutMapping("/enable/{id}")
    public Result<Boolean> enableUser(@PathVariable Long id) {
        try {
            // 检查权限
            if (!AuthContext.isAdmin()) {
                return Result.error(403, "只有管理员可以启用用户");
            }

            boolean success = userService.enableUser(id);
            if (success) {
                return Result.success(true);
            } else {
                return Result.error("启用用户失败");
            }
        } catch (Exception e) {
            log.error("启用用户失败", e);
            return Result.error("启用用户失败：" + e.getMessage());
        }
    }

    /**
     * 禁用用户
     */
    @PutMapping("/disable/{id}")
    public Result<Boolean> disableUser(@PathVariable Long id) {
        try {
            // 检查权限
            if (!AuthContext.isAdmin()) {
                return Result.error(403, "只有管理员可以禁用用户");
            }

            boolean success = userService.disableUser(id);
            if (success) {
                return Result.success(true);
            } else {
                return Result.error("禁用用户失败");
            }
        } catch (Exception e) {
            log.error("禁用用户失败", e);
            return Result.error("禁用用户失败：" + e.getMessage());
        }
    }

    /**
     * 删除用户
     */
    @DeleteMapping("/delete/{id}")
    public Result<Boolean> deleteUser(@PathVariable Long id) {
        try {
            // 检查权限
            if (!AuthContext.isAdmin()) {
                return Result.error(403, "只有管理员可以删除用户");
            }

            boolean success = userService.deleteUser(id);
            if (success) {
                return Result.success(true);
            } else {
                return Result.error("删除用户失败");
            }
        } catch (Exception e) {
            log.error("删除用户失败", e);
            return Result.error("删除用户失败：" + e.getMessage());
        }
    }

    /**
     * 批量删除用户
     */
    @DeleteMapping("/batchDelete")
    public Result<Boolean> batchDeleteUsers(@RequestParam("ids") List<Long> ids) {
        try {
            // 检查权限
            if (!AuthContext.isAdmin()) {
                return Result.error(403, "只有管理员可以批量删除用户");
            }

            for (Long id : ids) {
                userService.deleteUser(id);
            }
            return Result.success(true);
        } catch (Exception e) {
            log.error("批量删除用户失败", e);
            return Result.error("批量删除用户失败：" + e.getMessage());
        }
    }

    /**
     * 从请求头中提取token
     */
    private String extractToken(HttpServletRequest request) {
        String authHeader = request.getHeader("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            return authHeader.substring(7);
        }
        return null;
    }
}