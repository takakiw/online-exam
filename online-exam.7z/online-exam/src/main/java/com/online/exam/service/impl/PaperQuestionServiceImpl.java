package com.online.exam.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.online.exam.entity.PaperQuestion;
import com.online.exam.mapper.PaperQuestionMapper;
import com.online.exam.service.PaperQuestionService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PaperQuestionServiceImpl extends ServiceImpl<PaperQuestionMapper, PaperQuestion> implements PaperQuestionService {

    @Override
    public List<PaperQuestion> getPaperQuestions(Long paperId) {
        LambdaQueryWrapper<PaperQuestion> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(PaperQuestion::getPaperId, paperId)
                .orderByAsc(PaperQuestion::getSortOrder);
        return list(wrapper);
    }
}