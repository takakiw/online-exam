package com.online.exam.dto;

import lombok.Data;

@Data
public class ClassStudentQueryDTO {

    private Long classId;

    private String keyword;

    private Integer status;

    private Integer pageNum = 1;

    private Integer pageSize = 10;
}