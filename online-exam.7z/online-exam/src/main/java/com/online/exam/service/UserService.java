package com.online.exam.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.online.exam.dto.*;
import com.online.exam.entity.User;
import com.online.exam.entity.UserToken;

public interface UserService extends IService<User> {

    UserToken login(UserLoginDTO dto);

    boolean register(UserRegisterDTO dto);

    boolean logout(String token);

    User getCurrentUser(String token);

    Page<User> queryUsers(UserQueryDTO dto);

    boolean updateUser(Long userId, UserUpdateDTO dto);

    boolean updatePassword(Long userId, PasswordUpdateDTO dto);

    boolean resetPassword(Long userId);

    boolean enableUser(Long userId);

    boolean disableUser(Long userId);

    boolean deleteUser(Long userId);

    User getUserByUsername(String username);

    boolean updateUserProfile(Long userId, UserUpdateDTO dto);
}