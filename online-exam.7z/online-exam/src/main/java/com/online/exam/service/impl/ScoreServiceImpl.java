package com.online.exam.service.impl;

import com.alibaba.fastjson2.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.online.exam.common.AuthContext;
import com.online.exam.dto.ScoreQueryDTO;
import com.online.exam.dto.ScoreSubmitDTO;
import com.online.exam.entity.*;
import com.online.exam.enums.ExamStatusEnum;
import com.online.exam.mapper.ExamScoreMapper;
import com.online.exam.service.*;
import com.online.exam.util.DeepSeekUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
public class ScoreServiceImpl extends ServiceImpl<ExamScoreMapper, ExamScore> implements ScoreService {

    @Autowired
    private ExamService examService;

    @Autowired
    private ExamAnswerService examAnswerService;

    @Autowired
    private PaperService paperService;

    @Autowired
    private DeepSeekUtil deepSeekUtil;

    @Autowired
    private QuestionService questionService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ExamScore judgeExam(Long examRecordId) {
        ExamRecord examRecord = examService.getById(examRecordId);
        if (examRecord == null) {
            throw new RuntimeException("考试记录不存在");
        }

        // 检查考试状态
        if (!ExamStatusEnum.SUBMITTED.getCode().equals(examRecord.getStatus())) {
            throw new RuntimeException("考试未提交，不能判卷");
        }

        // 获取试卷信息以获取及格分数
        Paper paper = paperService.getById(examRecord.getPaperId());
        if (paper == null) {
            throw new RuntimeException("试卷不存在");
        }

        Integer passScore = paper.getPassScore(); // 从试卷获取及格分数

        // 获取所有答案
        List<ExamAnswer> answers = examAnswerService.getExamAnswers(examRecordId);

        // 自动判卷（客观题）
        int totalScore = 0;
        int studentScore = 0;
        JSONObject scoreDetail = new JSONObject();

        for (ExamAnswer answer : answers) {
            totalScore += answer.getQuestionScore();

            // 判断客观题
            if (isObjectiveQuestion(answer)) {
                boolean isCorrect = judgeObjectiveAnswer(answer.getCorrectAnswer(), answer.getStudentAnswer());
                int score = isCorrect ? answer.getQuestionScore() : 0;

                answer.setIsCorrect(isCorrect);
                answer.setStudentScore(score);
                studentScore += score;

                examAnswerService.updateById(answer);

                // 记录得分详情
                JSONObject detail = new JSONObject();
                detail.put("questionId", answer.getQuestionId());
                detail.put("questionScore", answer.getQuestionScore());
                detail.put("studentScore", score);
                detail.put("isCorrect", isCorrect);
                scoreDetail.put(String.valueOf(answer.getQuestionId()), detail);
            }
        }

        // 判断是否及格
        boolean isPassed = studentScore >= passScore;

        // 更新考试记录
        examRecord.setScore(studentScore);
        examRecord.setIsPassed(isPassed);
        examRecord.setStatus(ExamStatusEnum.JUDGED.getCode());
        examService.updateById(examRecord);

        // 创建考试成绩
        ExamScore examScore = new ExamScore();
        examScore.setExamRecordId(examRecordId);
        examScore.setPaperId(examRecord.getPaperId());
        examScore.setPaperName(examRecord.getPaperName());
        examScore.setStudentId(examRecord.getStudentId());
        examScore.setStudentName(examRecord.getStudentName());
        examScore.setClassId(examRecord.getClassId());
        examScore.setClassName(examRecord.getClassName());
        examScore.setTeacherId(examRecord.getTeacherId());
        examScore.setTotalScore(totalScore);
        examScore.setScore(studentScore);
        examScore.setPassScore(passScore); // 设置及格分数
        examScore.setIsPassed(isPassed);
        examScore.setScoreDetail(scoreDetail);
        examScore.setSubmitTime(examRecord.getSubmitTime());
        examScore.setJudgeTime(LocalDateTime.now());

        save(examScore);

        log.info("自动判卷完成，考试记录ID：{}，得分：{}/{}，及格分数：{}",
                examRecordId, studentScore, totalScore, passScore);

        return examScore;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean manualJudge(ScoreSubmitDTO dto) {
        ExamRecord examRecord = examService.getById(dto.getExamRecordId());
        if (examRecord == null) {
            throw new RuntimeException("考试记录不存在");
        }

        // 检查权限
        if (!examService.isExamTeacher(examRecord.getPaperId(), AuthContext.getCurrentUserId())) {
            throw new RuntimeException("没有权限判卷");
        }

        // 获取试卷信息以获取及格分数
        Paper paper = paperService.getById(examRecord.getPaperId());
        if (paper == null) {
            throw new RuntimeException("试卷不存在");
        }

        Integer passScore = paper.getPassScore(); // 从试卷获取及格分数

        int totalScore = 0;
        int studentScore = 0;
        JSONObject scoreDetail = new JSONObject();

        // 更新题目得分
        for (ScoreSubmitDTO.QuestionScoreDTO questionScore : dto.getQuestionScores()) {
            ExamAnswer answer = examAnswerService.getExamAnswer(dto.getExamRecordId(), questionScore.getQuestionId());
            if (answer != null) {
                answer.setStudentScore(questionScore.getStudentScore());
                answer.setIsCorrect(questionScore.getStudentScore() > 0);
                examAnswerService.updateById(answer);

                totalScore += answer.getQuestionScore();
                studentScore += questionScore.getStudentScore();

                // 记录得分详情
                JSONObject detail = new JSONObject();
                detail.put("questionId", answer.getQuestionId());
                detail.put("questionScore", answer.getQuestionScore());
                detail.put("studentScore", questionScore.getStudentScore());
                detail.put("isCorrect", questionScore.getStudentScore() > 0);
                scoreDetail.put(String.valueOf(answer.getQuestionId()), detail);
            }
        }

        // 判断是否及格
        boolean isPassed = studentScore >= passScore;

        // 更新考试记录
        examRecord.setScore(studentScore);
        examRecord.setIsPassed(isPassed);
        examRecord.setStatus(ExamStatusEnum.JUDGED.getCode());
        examService.updateById(examRecord);

        // 更新或创建考试成绩
        ExamScore examScore = baseMapper.selectByExamRecordId(dto.getExamRecordId());
        if (examScore == null) {
            examScore = new ExamScore();
            examScore.setExamRecordId(dto.getExamRecordId());
            examScore.setPaperId(examRecord.getPaperId());
            examScore.setPaperName(examRecord.getPaperName());
            examScore.setStudentId(examRecord.getStudentId());
            examScore.setStudentName(examRecord.getStudentName());
            examScore.setClassId(examRecord.getClassId());
            examScore.setClassName(examRecord.getClassName());
            examScore.setTeacherId(examRecord.getTeacherId());
            examScore.setSubmitTime(examRecord.getSubmitTime());
        }

        examScore.setTotalScore(totalScore);
        examScore.setScore(studentScore);
        examScore.setPassScore(passScore); // 设置及格分数
        examScore.setIsPassed(isPassed);
        examScore.setScoreDetail(scoreDetail);
        examScore.setJudgeTime(LocalDateTime.now());

        saveOrUpdate(examScore);

        return true;
    }

    @Override
    public Page<ExamScore> queryScores(ScoreQueryDTO dto) {
        Page<ExamScore> page = new Page<>(dto.getPageNum(), dto.getPageSize());
        return baseMapper.selectScorePage(page, dto);
    }

    @Override
    public ExamScore getScoreDetail(Long examRecordId) {
        return baseMapper.selectByExamRecordId(examRecordId);
    }

    @Override
    public List<ExamScore> getClassScores(Long classId, Long paperId) {
        LambdaQueryWrapper<ExamScore> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ExamScore::getClassId, classId);
        if (paperId != null) {
            wrapper.eq(ExamScore::getPaperId, paperId);
        }
        wrapper.orderByDesc(ExamScore::getScore);
        return list(wrapper);
    }

    @Override
    public JSONObject getScoreStatistics(Long paperId, Long classId) {
        LambdaQueryWrapper<ExamScore> wrapper = new LambdaQueryWrapper<>();
        if (paperId != null) {
            wrapper.eq(ExamScore::getPaperId, paperId);
        }
        if (classId != null) {
            wrapper.eq(ExamScore::getClassId, classId);
        }

        List<ExamScore> scores = list(wrapper);

        JSONObject statistics = new JSONObject();
        statistics.put("totalCount", scores.size());

        if (scores.isEmpty()) {
            return statistics;
        }

        // 计算平均分、最高分、最低分
        double totalScore = scores.stream().mapToInt(ExamScore::getScore).sum();
        int maxScore = scores.stream().mapToInt(ExamScore::getScore).max().orElse(0);
        int minScore = scores.stream().mapToInt(ExamScore::getScore).min().orElse(0);
        long passedCount = scores.stream().filter(ExamScore::getIsPassed).count();

        statistics.put("averageScore", totalScore / scores.size());
        statistics.put("maxScore", maxScore);
        statistics.put("minScore", minScore);
        statistics.put("passedCount", passedCount);
        statistics.put("passedRate", (double) passedCount / scores.size() * 100);

        // 分数段统计
        Map<String, Long> scoreDistribution = scores.stream()
                .collect(Collectors.groupingBy(
                        score -> getScoreRange(score.getScore()),
                        Collectors.counting()
                ));
        statistics.put("scoreDistribution", scoreDistribution);

        return statistics;
    }

    @Override
    public JSONObject getStudentStatistics(Long studentId) {
        LambdaQueryWrapper<ExamScore> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ExamScore::getStudentId, studentId);

        List<ExamScore> scores = list(wrapper);

        JSONObject statistics = new JSONObject();
        statistics.put("totalExams", scores.size());

        if (scores.isEmpty()) {
            return statistics;
        }

        // 计算学生统计
        double totalScore = scores.stream().mapToInt(ExamScore::getScore).sum();
        double totalMaxScore = scores.stream().mapToInt(ExamScore::getTotalScore).sum();
        long passedCount = scores.stream().filter(ExamScore::getIsPassed).count();

        statistics.put("averageScore", totalScore / scores.size());
        statistics.put("totalScoreRate", totalScore / totalMaxScore * 100);
        statistics.put("passedCount", passedCount);
        statistics.put("passedRate", (double) passedCount / scores.size() * 100);

        // 最近5次考试记录
        List<ExamScore> recentScores = scores.stream()
                .sorted((a, b) -> b.getSubmitTime().compareTo(a.getSubmitTime()))
                .limit(5)
                .collect(Collectors.toList());
        statistics.put("recentScores", recentScores);

        return statistics;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ExamScore aiJudgeExam(Long examRecordId) {
        ExamRecord examRecord = examService.getById(examRecordId);
        if (examRecord == null) {
            throw new RuntimeException("考试记录不存在");
        }

        if (!examRecord.getAiJudgeEnabled()) {
            throw new RuntimeException("该试卷未开启AI判卷");
        }

        // 获取试卷信息以获取及格分数
        Paper paper = paperService.getById(examRecord.getPaperId());
        if (paper == null) {
            throw new RuntimeException("试卷不存在");
        }

        Integer passScore = paper.getPassScore(); // 从试卷获取及格分数

        // 获取试卷题目
        List<PaperQuestion> paperQuestions = paperService.getPaperQuestions(examRecord.getPaperId());
        List<ExamAnswer> answers = examAnswerService.getExamAnswers(examRecordId);

        int totalScore = 0;
        int studentScore = 0;
        JSONObject scoreDetail = new JSONObject();

        for (ExamAnswer answer : answers) {
            totalScore += answer.getQuestionScore();

            // 如果是主观题，使用AI判卷
            if ("subjective".equals(getQuestionType(answer.getQuestionId(), paperQuestions))) {
                PaperQuestion question = paperQuestions.stream()
                        .filter(q -> q.getQuestionId().equals(answer.getQuestionId()))
                        .findFirst()
                        .orElse(null);

                if (question != null) {
                    JSONObject aiResult = deepSeekUtil.judgeSubjectiveQuestion(
                            question.getQuestionContent(),
                            question.getQuestionAnswer(),
                            answer.getStudentAnswer(),
                            question.getQuestionScore()
                    );

                    int aiScore = aiResult.getIntValue("score");
                    answer.setStudentScore(aiScore);
                    answer.setAiJudgeResult(aiResult.toJSONString());
                    answer.setIsCorrect(aiScore > 0);

                    studentScore += aiScore;

                    // 记录AI判卷详情
                    JSONObject detail = new JSONObject();
                    detail.put("questionId", answer.getQuestionId());
                    detail.put("questionScore", answer.getQuestionScore());
                    detail.put("studentScore", aiScore);
                    detail.put("isCorrect", aiScore > 0);
                    detail.put("aiComment", aiResult.getString("comment"));
                    detail.put("aiSuggestions", aiResult.getString("suggestions"));
                    scoreDetail.put(String.valueOf(answer.getQuestionId()), detail);
                }
            } else {
                // 客观题自动判卷
                boolean isCorrect = judgeObjectiveAnswer(answer.getCorrectAnswer(), answer.getStudentAnswer());
                int score = isCorrect ? answer.getQuestionScore() : 0;

                answer.setIsCorrect(isCorrect);
                answer.setStudentScore(score);
                studentScore += score;

                // 记录客观题详情
                JSONObject detail = new JSONObject();
                detail.put("questionId", answer.getQuestionId());
                detail.put("questionScore", answer.getQuestionScore());
                detail.put("studentScore", score);
                detail.put("isCorrect", isCorrect);
                scoreDetail.put(String.valueOf(answer.getQuestionId()), detail);
            }

            examAnswerService.updateById(answer);
        }

        // 判断是否及格
        boolean isPassed = studentScore >= passScore;

        // 更新考试记录
        examRecord.setScore(studentScore);
        examRecord.setIsPassed(isPassed);
        examRecord.setStatus(ExamStatusEnum.JUDGED.getCode());
        examService.updateById(examRecord);

        // 创建考试成绩
        ExamScore examScore = new ExamScore();
        examScore.setExamRecordId(examRecordId);
        examScore.setPaperId(examRecord.getPaperId());
        examScore.setPaperName(examRecord.getPaperName());
        examScore.setStudentId(examRecord.getStudentId());
        examScore.setStudentName(examRecord.getStudentName());
        examScore.setClassId(examRecord.getClassId());
        examScore.setClassName(examRecord.getClassName());
        examScore.setTeacherId(examRecord.getTeacherId());
        examScore.setTotalScore(totalScore);
        examScore.setScore(studentScore);
        examScore.setPassScore(passScore); // 设置及格分数
        examScore.setIsPassed(isPassed);
        examScore.setScoreDetail(scoreDetail);
        examScore.setSubmitTime(examRecord.getSubmitTime());
        examScore.setJudgeTime(LocalDateTime.now());

        save(examScore);

        log.info("AI判卷完成，考试记录ID：{}，得分：{}/{}，及格分数：{}",
                examRecordId, studentScore, totalScore, passScore);

        return examScore;
    }

    // 辅助方法
    private boolean isObjectiveQuestion(ExamAnswer answer) {
        // 根据题目类型判断是否是客观题
        String correctAnswer = answer.getCorrectAnswer();
        return correctAnswer != null && !correctAnswer.trim().isEmpty() &&
                !"subjective".equals(getQuestionType(answer.getQuestionId()));
    }

    private boolean judgeObjectiveAnswer(String correctAnswer, String studentAnswer) {
        if (studentAnswer == null || studentAnswer.trim().isEmpty()) {
            return false;
        }
        // 简化判断逻辑
        return correctAnswer != null && correctAnswer.trim().equalsIgnoreCase(studentAnswer.trim());
    }

    private String getQuestionType(Long questionId) {
        // 根据题目ID查询题目类型
        return questionService.getById(questionId).getType();
    }

    private String getQuestionType(Long questionId, List<PaperQuestion> paperQuestions) {
        return paperQuestions.stream()
                .filter(q -> q.getQuestionId().equals(questionId))
                .map(PaperQuestion::getQuestionType)
                .findFirst()
                .orElse("single_choice");
    }

    private String getScoreRange(int score) {
        if (score >= 90) return "90-100";
        if (score >= 80) return "80-89";
        if (score >= 70) return "70-79";
        if (score >= 60) return "60-69";
        return "0-59";
    }

    // ... 其他方法保持不变 ...
}