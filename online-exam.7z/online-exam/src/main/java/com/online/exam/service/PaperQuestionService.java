package com.online.exam.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.online.exam.entity.PaperQuestion;

import java.util.List;

public interface PaperQuestionService extends IService<PaperQuestion> {

    List<PaperQuestion> getPaperQuestions(Long paperId);
}