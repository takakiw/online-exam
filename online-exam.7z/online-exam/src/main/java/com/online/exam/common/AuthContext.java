package com.online.exam.common;

import lombok.Data;

@Data
public class AuthContext {

    private Long userId;
    private String username;
    private String role;

    private static final ThreadLocal<AuthContext> contextHolder = new ThreadLocal<>();

    public static void setContext(AuthContext context) {
        contextHolder.set(context);
    }

    public static AuthContext getContext() {
        return contextHolder.get();
    }

    public static void clearContext() {
        contextHolder.remove();
    }

    public static Long getCurrentUserId() {
        AuthContext context = getContext();
        return context != null ? context.getUserId() : null;
    }

    public static String getCurrentUsername() {
        AuthContext context = getContext();
        return context != null ? context.getUsername() : null;
    }

    public static String getCurrentRole() {
        AuthContext context = getContext();
        return context != null ? context.getRole() : null;
    }

    public static boolean isAdmin() {
        return Constants.ROLE_ADMIN.equals(getCurrentRole());
    }

    public static boolean isTeacher() {
        return Constants.ROLE_TEACHER.equals(getCurrentRole());
    }

    public static boolean isStudent() {
        return Constants.ROLE_STUDENT.equals(getCurrentRole());
    }
}