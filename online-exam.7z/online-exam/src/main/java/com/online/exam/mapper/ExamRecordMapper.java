package com.online.exam.mapper;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.online.exam.dto.ExamQueryDTO;
import com.online.exam.entity.ExamRecord;
import org.apache.ibatis.annotations.Param;
import java.time.LocalDateTime;

public interface ExamRecordMapper extends BaseMapper<ExamRecord> {

    default Page<ExamRecord> selectExamPage(Page<ExamRecord> page, ExamQueryDTO dto) {
        LambdaQueryWrapper<ExamRecord> wrapper = new LambdaQueryWrapper<>();

        if (dto.getPaperId() != null) {
            wrapper.eq(ExamRecord::getPaperId, dto.getPaperId());
        }
        if (dto.getStudentId() != null) {
            wrapper.eq(ExamRecord::getStudentId, dto.getStudentId());
        }
        if (dto.getClassId() != null) {
            wrapper.eq(ExamRecord::getClassId, dto.getClassId());
        }
        if (dto.getTeacherId() != null) {
            wrapper.eq(ExamRecord::getTeacherId, dto.getTeacherId());
        }
        if (dto.getStatus() != null) {
            wrapper.eq(ExamRecord::getStatus, dto.getStatus());
        }
        if (dto.getIsPassed() != null) {
            wrapper.eq(ExamRecord::getIsPassed, dto.getIsPassed());
        }

        wrapper.orderByDesc(ExamRecord::getCreateTime);
        return selectPage(page, wrapper);
    }

    default ExamRecord selectByPaperAndStudent(Long paperId, Long studentId) {
        LambdaQueryWrapper<ExamRecord> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ExamRecord::getPaperId, paperId)
                .eq(ExamRecord::getStudentId, studentId);
        return selectOne(wrapper);
    }

    default boolean updateExamStatus(Long id, Integer status) {
        ExamRecord record = new ExamRecord();
        record.setId(id);
        record.setStatus(status);
        if (status == 1) { // 已提交
            record.setSubmitTime(LocalDateTime.now());
        }
        return updateById(record) > 0;
    }

    default boolean updateExamScore(Long id, Integer score, Boolean isPassed) {
        ExamRecord record = new ExamRecord();
        record.setId(id);
        record.setScore(score);
        record.setIsPassed(isPassed);
        record.setStatus(2); // 已判卷
        return updateById(record) > 0;
    }
}