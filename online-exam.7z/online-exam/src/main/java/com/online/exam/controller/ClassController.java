package com.online.exam.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.online.exam.common.AuthContext;
import com.online.exam.common.Result;
import com.online.exam.dto.*;
import com.online.exam.entity.ClassEntity;
import com.online.exam.entity.ClassStudent;
import com.online.exam.entity.User;
import com.online.exam.service.ClassService;
import com.online.exam.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@Slf4j
@Validated
@RestController
@RequestMapping("/api/class")
public class ClassController {

    @Autowired
    private ClassService classService;

    @Autowired
    private UserService userService;


    /**
     * 创建班级（教师）
     */
    @PostMapping("/create")
    public Result<ClassEntity> createClass(@Valid @RequestBody ClassCreateDTO dto) {
        try {
            Long teacherId = AuthContext.getCurrentUserId();
            String teacherName = AuthContext.getCurrentUsername();

            if (!AuthContext.isTeacher() && !AuthContext.isAdmin()) {
                return Result.error(403, "只有教师可以创建班级");
            }

            ClassEntity classEntity = classService.createClass(dto, teacherId, teacherName);
            return Result.success(classEntity);
        } catch (Exception e) {
            log.error("创建班级失败", e);
            return Result.error("创建班级失败：" + e.getMessage());
        }
    }

    /**
     * 更新班级信息（教师）
     */
    @PutMapping("/update/{classId}")
    public Result<Boolean> updateClass(@PathVariable Long classId, @Valid @RequestBody ClassUpdateDTO dto) {
        try {
            boolean success = classService.updateClass(classId, dto);
            return success ? Result.success(true) : Result.error("更新班级失败");
        } catch (Exception e) {
            log.error("更新班级失败", e);
            return Result.error("更新班级失败：" + e.getMessage());
        }
    }

    /**
     * 删除班级（教师）
     */
    @DeleteMapping("/delete/{classId}")
    public Result<Boolean> deleteClass(@PathVariable Long classId) {
        try {
            boolean success = classService.deleteClass(classId);
            return success ? Result.success(true) : Result.error("删除班级失败");
        } catch (Exception e) {
            log.error("删除班级失败", e);
            return Result.error("删除班级失败：" + e.getMessage());
        }
    }

    /**
     * 结束班级（教师）
     */
    @PutMapping("/end/{classId}")
    public Result<Boolean> endClass(@PathVariable Long classId) {
        try {
            boolean success = classService.endClass(classId);
            return success ? Result.success(true) : Result.error("结束班级失败");
        } catch (Exception e) {
            log.error("结束班级失败", e);
            return Result.error("结束班级失败：" + e.getMessage());
        }
    }

    /**
     * 重新开启班级（教师）
     */
    @PutMapping("/reopen/{classId}")
    public Result<Boolean> reopenClass(@PathVariable Long classId) {
        try {
            boolean success = classService.reopenClass(classId);
            return success ? Result.success(true) : Result.error("重新开启班级失败");
        } catch (Exception e) {
            log.error("重新开启班级失败", e);
            return Result.error("重新开启班级失败：" + e.getMessage());
        }
    }

    /**
     * 查询班级列表
     */
    @PostMapping("/query")
    public Result<Page<ClassEntity>> queryClasses(@Valid @RequestBody ClassQueryDTO dto) {
        try {
            Page<ClassEntity> page = classService.queryClasses(dto);
            return Result.success(page, page.getTotal());
        } catch (Exception e) {
            log.error("查询班级列表失败", e);
            return Result.error("查询班级列表失败：" + e.getMessage());
        }
    }

    /**
     * 查询班级详情
     */
    @GetMapping("/detail/{classId}")
    public Result<ClassEntity> getClassDetail(@PathVariable Long classId) {
        try {
            ClassEntity classEntity = classService.getClassDetail(classId);
            if (classEntity == null) {
                return Result.error(404, "班级不存在");
            }
            return Result.success(classEntity);
        } catch (Exception e) {
            log.error("查询班级详情失败", e);
            return Result.error("查询班级详情失败：" + e.getMessage());
        }
    }

    /**
     * 查询我创建的班级（教师）
     */
    @GetMapping("/my-teacher-classes")
    public Result<Page<ClassEntity>> getMyTeacherClasses(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize) {
        try {
            if (!AuthContext.isTeacher() && !AuthContext.isAdmin()) {
                return Result.error(403, "只有教师可以查看创建的班级");
            }

            ClassQueryDTO dto = new ClassQueryDTO();
            dto.setTeacherId(AuthContext.getCurrentUserId());
            dto.setPageNum(pageNum);
            dto.setPageSize(pageSize);

            Page<ClassEntity> page = classService.queryClasses(dto);
            return Result.success(page, page.getTotal());
        } catch (Exception e) {
            log.error("查询我创建的班级失败", e);
            return Result.error("查询我创建的班级失败：" + e.getMessage());
        }
    }

    // ==================== 邀请码管理 ====================

    /**
     * 生成邀请码（教师）
     */
    @PostMapping("/invite-code/{classId}")
    public Result<String> generateInviteCode(@PathVariable Long classId,
                                             @RequestParam(defaultValue = "7") Integer expireDays) {
        try {
            if (!AuthContext.isTeacher() && !AuthContext.isAdmin()) {
                return Result.error(403, "只有教师可以生成邀请码");
            }

            String inviteCode = classService.generateInviteCode(classId, expireDays);
            return Result.success(inviteCode);
        } catch (Exception e) {
            log.error("生成邀请码失败", e);
            return Result.error("生成邀请码失败：" + e.getMessage());
        }
    }

    /**
     * 禁用邀请码（教师）
     */
    @DeleteMapping("/invite-code/{classId}")
    public Result<Boolean> disableInviteCode(@PathVariable Long classId) {
        try {
            if (!AuthContext.isTeacher()) {
                return Result.error(403, "只有教师可以禁用邀请码");
            }

            boolean success = classService.disableInviteCode(classId);
            return success ? Result.success(true) : Result.error("禁用邀请码失败");
        } catch (Exception e) {
            log.error("禁用邀请码失败", e);
            return Result.error("禁用邀请码失败：" + e.getMessage());
        }
    }

    // ==================== 学生管理 ====================

    /**
     * 加入班级（学生）
     */
    @PostMapping("/join")
    public Result<Boolean> joinClass(@Valid @RequestBody ClassJoinDTO dto) {
        try {
            if (!AuthContext.isStudent()) {
                return Result.error(403, "只有学生可以加入班级");
            }

            Long studentId = AuthContext.getCurrentUserId();
            String username = AuthContext.getCurrentUsername();

            // 获取用户信息
            User user = userService.getById(studentId);
            if (user == null) {
                return Result.error("用户不存在");
            }

            boolean success = classService.joinClass(dto.getInviteCode(), studentId,
                    user.getNickname(), username);
            return success ? Result.success(true) : Result.error("加入班级失败");
        } catch (Exception e) {
            log.error("加入班级失败", e);
            return Result.error("加入班级失败：" + e.getMessage());
        }
    }

    /**
     * 退出班级（学生）
     */
    @PostMapping("/leave/{classId}")
    public Result<Boolean> leaveClass(@PathVariable Long classId) {
        try {
            if (!AuthContext.isStudent()) {
                return Result.error(403, "只有学生可以退出班级");
            }

            Long studentId = AuthContext.getCurrentUserId();
            boolean success = classService.leaveClass(classId, studentId);
            return success ? Result.success(true) : Result.error("退出班级失败");
        } catch (Exception e) {
            log.error("退出班级失败", e);
            return Result.error("退出班级失败：" + e.getMessage());
        }
    }

    /**
     * 移除学生（教师）
     */
    @DeleteMapping("/remove-student/{classId}/{studentId}")
    public Result<Boolean> removeStudent(@PathVariable Long classId, @PathVariable Long studentId) {
        try {
            if (!AuthContext.isTeacher()) {
                return Result.error(403, "只有教师可以移除学生");
            }

            boolean success = classService.removeStudent(classId, studentId);
            return success ? Result.success(true) : Result.error("移除学生失败");
        } catch (Exception e) {
            log.error("移除学生失败", e);
            return Result.error("移除学生失败：" + e.getMessage());
        }
    }

    /**
     * 查询班级学生列表
     */
    @PostMapping("/students")
    public Result<Page<ClassStudent>> queryClassStudents(@Valid @RequestBody ClassStudentQueryDTO dto) {
        try {
            Page<ClassStudent> page = classService.queryClassStudents(dto);
            return Result.success(page, page.getTotal());
        } catch (Exception e) {
            log.error("查询班级学生列表失败", e);
            return Result.error("查询班级学生列表失败：" + e.getMessage());
        }
    }

    /**
     * 查询我加入的班级（学生）
     */
    @GetMapping("/my-student-classes")
    public Result<Page<ClassStudent>> getMyStudentClasses(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize) {
        try {
            if (!AuthContext.isStudent()) {
                return Result.error(403, "只有学生可以查看加入的班级");
            }

            Long studentId = AuthContext.getCurrentUserId();
            Page<ClassStudent> page = classService.queryStudentClasses(studentId, pageNum, pageSize);
            return Result.success(page, page.getTotal());
        } catch (Exception e) {
            log.error("查询我加入的班级失败", e);
            return Result.error("查询我加入的班级失败：" + e.getMessage());
        }
    }

    /**
     * 查询班级信息（包含是否已加入）
     */
    @GetMapping("/info/{classId}")
    public Result<ClassEntity> getClassInfo(@PathVariable Long classId) {
        try {
            ClassEntity classEntity = classService.getClassDetail(classId);
            if (classEntity == null) {
                return Result.error(404, "班级不存在");
            }

            // 如果是学生，检查是否已加入
            if (AuthContext.isStudent()) {
                Long studentId = AuthContext.getCurrentUserId();
                boolean isJoined = classService.isClassStudent(classId, studentId);
                classEntity.setInviteCode(isJoined ? "已加入" : null);
            }

            return Result.success(classEntity);
        } catch (Exception e) {
            log.error("查询班级信息失败", e);
            return Result.error("查询班级信息失败：" + e.getMessage());
        }
    }
}