package com.online.exam;

import com.online.exam.util.DeepSeekUtil;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * @author xiaowenyu
 * @date 2026-01-30 17:27
 */

@SpringBootTest
public class DSTest {

    @Autowired
    private DeepSeekUtil deepSeekUtil;

    @Value("${deepseek.api-key}")
    private String apiKey;

    @Test
    public void test() {
        System.out.println("apiKey:" + apiKey);
        String questionContent = "请解析以下题目：\n" +
                "题目：\n" +
                "1+1=?\n" +
                "答案：\n" +
                "2\n" +
                "请给出详细的解析过程和知识点说明。";
        String answer = "2";
        String result = deepSeekUtil.analyzeQuestion(questionContent, answer);
        System.out.println(result);
    }

}
